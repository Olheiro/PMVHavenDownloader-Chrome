// Offscreen helper: service workers can't call URL.createObjectURL(), so
// background.js stages the finished MP4 in IndexedDB and asks this page to
// turn it into a blob: URL that chrome.downloads can fetch.

const BLOB_DB_NAME = 'pmv-downloader-blobs';
const BLOB_STORE = 'blobs';

function openDb() {
  return new Promise((resolve, reject) => {
    const req = indexedDB.open(BLOB_DB_NAME, 1);
    req.onupgradeneeded = () => req.result.createObjectStore(BLOB_STORE);
    req.onsuccess = () => resolve(req.result);
    req.onerror = () => reject(req.error);
  });
}

async function dbGet(key) {
  const db = await openDb();
  try {
    return await new Promise((resolve, reject) => {
      const req = db.transaction(BLOB_STORE, 'readonly').objectStore(BLOB_STORE).get(key);
      req.onsuccess = () => resolve(req.result);
      req.onerror = () => reject(req.error);
    });
  } finally {
    db.close();
  }
}

async function dbDelete(key) {
  const db = await openDb();
  try {
    await new Promise((resolve, reject) => {
      const tx = db.transaction(BLOB_STORE, 'readwrite');
      tx.objectStore(BLOB_STORE).delete(key);
      tx.oncomplete = () => resolve();
      tx.onerror = () => reject(tx.error);
    });
  } finally {
    db.close();
  }
}

chrome.runtime.onMessage.addListener((msg, _sender, sendResponse) => {
  if (!msg || msg.target !== 'offscreen') return false;

  if (msg.type === 'MAKE_BLOB_URL') {
    dbGet(msg.key)
      .then((blob) => {
        if (!blob) throw new Error('Staged file not found');
        sendResponse({ ok: true, url: URL.createObjectURL(blob) });
      })
      .catch((e) => sendResponse({ ok: false, error: String(e && e.message ? e.message : e) }));
    return true; // async response
  }

  if (msg.type === 'RELEASE_BLOB') {
    if (msg.url) URL.revokeObjectURL(msg.url);
    dbDelete(msg.key)
      .catch(() => {})
      .then(() => sendResponse({ ok: true }));
    return true;
  }

  return false;
});
