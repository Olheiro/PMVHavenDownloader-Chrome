const browser = globalThis.browser || chrome;

// popup.js
//
// background.js owns all actual downloading (see the comment there) and
// tracks one entry per (tab, resolution) pair, so a single tab can run
// several resolution downloads at once. This file always shows the same
// layout - title/creator/uploader, the resolution list, filename field,
// and Download button never disappear. When a resolution starts
// downloading, that specific row swaps from its checkbox to an inline
// progress readout (bar, speed, status, pause/cancel/dismiss) right where
// the checkbox was, instead of the popup jumping to a different screen.
//
// Flow:
// 1. On open, figures out which tab it belongs to, loads this tab's video
//    info/resolutions from the content script as usual, then asks
//    background.js for any downloads already tracked for this tab and
//    switches those specific rows into progress mode immediately.
// 2. Clicking Download starts one background download per checked
//    (non-active) resolution, each named "<base filename> - <resolution>.mp4",
//    and immediately shows that row's progress inline.
// 3. Live STATE_UPDATE broadcasts from background.js update/clear the
//    matching row's inline progress as it happens.

const STORAGE_KEY_INCLUDE_CREATOR = 'includeCreatorInFilename';
const STORAGE_KEY_INCLUDE_UPLOADER = 'includeUploaderInFilename';
const STORAGE_KEY_INCLUDE_RESOLUTION = 'includeResolutionInFilename';
const STORAGE_KEY_DARK_MODE = 'darkModeEnabled';

let myTabId = null;
let currentInfo = null;
let variants = []; // [{ label, url }]
let includeCreator = true; // persisted setting, default on
let includeUploader = true; // persisted setting, default on
let includeResolution = true; // persisted setting, default on
let darkModeEnabled = true; // persisted setting, default on
let lastAutoBaseName = ''; // tracks the last auto-generated base name so we know if the user edited it

// resolutionLabel -> row elements (see ensureRow)
const resolutionRows = new Map();

function sanitize(name) {
  return name
    .replace(/[\\/:*?"<>|]/g, '') // strip characters illegal in filenames
    .replace(/\s+/g, ' ')
    .trim();
}

// Builds the base filename (title/creator/uploader per the toggles), with
// no extension and no resolution - the resolution is appended per-download
// when a download actually starts, since one base name can produce several
// files (one per selected resolution).
function buildBaseName(info, includeCreatorInName, includeUploaderInName) {
  const parts = [];
  const seen = new Set();

  if (info.title) {
    parts.push(info.title);
    seen.add(info.title);
  }
  if (includeCreatorInName && info.creator && !seen.has(info.creator)) {
    parts.push(info.creator);
    seen.add(info.creator);
  }
  if (includeUploaderInName && info.uploader && !seen.has(info.uploader)) {
    parts.push(`up by ${info.uploader}`);
    seen.add(info.uploader);
  }

  return sanitize(parts.join(' - ')) || 'pmvhaven-video';
}

function finalizeBaseName(rawValue) {
  const name = sanitize(rawValue || '');
  return name || 'pmvhaven-video';
}

function filenameForResolution(baseName, resolutionLabel, includeResolutionInName) {
  const base = sanitize(baseName);
  return includeResolutionInName ? `${base} - ${resolutionLabel}.mp4` : `${base}.mp4`;
}

const ORIGINAL_LABEL = 'Original (non-transcoded)';

// File extension for the original upload: taken from its URL, else its
// mimetype, else mp4.
function originalExtension(original) {
  try {
    const m = new URL(original.url).pathname.match(/\.([a-z0-9]{2,5})$/i);
    if (m) return m[1].toLowerCase();
  } catch (e) {
    // fall through
  }
  const mime = (original.mimetype || '').toLowerCase();
  if (mime.includes('quicktime')) return 'mov';
  if (mime.includes('webm')) return 'webm';
  if (mime.includes('matroska')) return 'mkv';
  return 'mp4';
}

// <title> - <creator> - <uploader> - <resolution> - original.<ext>
// (title/creator/uploader come from the shared base name, exactly like the
// transcoded files, and the resolution part follows the same toggle.)
function filenameForOriginal(baseName, variant, includeResolutionInName) {
  const base = sanitize(baseName);
  const res = includeResolutionInName && variant.resolution ? ` - ${variant.resolution}` : '';
  return `${base}${res} - original.${variant.extension}`;
}

function makeOriginalVariant(original) {
  return {
    label: ORIGINAL_LABEL,
    isOriginal: true,
    url: original.url,
    fileSize: original.fileSize || null,
    resolution: original.height ? `${original.height}p` : '',
    extension: originalExtension(original),
  };
}

function resolveUrl(base, relative) {
  return new URL(relative, base).href;
}

async function fetchText(url) {
  const res = await fetch(url);
  if (!res.ok) throw new Error(`HTTP ${res.status} loading ${url}`);
  return res.text();
}

// Parses an HLS master playlist and returns the resolution variants it lists.
function parseMasterPlaylist(text, baseUrl) {
  const lines = text.split('\n').map((l) => l.trim());
  const found = [];
  for (let i = 0; i < lines.length; i++) {
    if (lines[i].startsWith('#EXT-X-STREAM-INF')) {
      const resMatch = lines[i].match(/RESOLUTION=\d+x(\d+)/);
      const bwMatch = lines[i].match(/BANDWIDTH=(\d+)/);
      const avgBwMatch = lines[i].match(/AVERAGE-BANDWIDTH=(\d+)/);
      const uriLine = lines[i + 1];
      if (uriLine && !uriLine.startsWith('#')) {
        found.push({
          label: resMatch
            ? `${resMatch[1]}p`
            : bwMatch
            ? `${Math.round(Number(bwMatch[1]) / 1000)} kbps`
            : 'variant',
          url: resolveUrl(baseUrl, uriLine),
          // AVERAGE-BANDWIDTH (bits/sec) is a better size estimate than the
          // (often peak) BANDWIDTH value when both are present.
          bandwidthBitsPerSec: avgBwMatch ? Number(avgBwMatch[1]) : bwMatch ? Number(bwMatch[1]) : null,
        });
      }
    }
  }
  return found;
}

function formatBytes(bytes) {
  if (!isFinite(bytes) || bytes <= 0) return '';
  if (bytes >= 1024 * 1024 * 1024) return `${(bytes / (1024 * 1024 * 1024)).toFixed(1)} GB`;
  if (bytes >= 1024 * 1024) return `${(bytes / (1024 * 1024)).toFixed(0)} MB`;
  return `${(bytes / 1024).toFixed(0)} kB`;
}

// Estimates a variant's file size in bytes from its playlist bandwidth and
// the video's duration (both approximate - HLS bandwidth values are nominal
// and pmvhaven's reported duration may round). Returns null when either
// input is missing.
function estimateSizeBytes(variant, durationSeconds) {
  if (variant.isOriginal) return variant.fileSize || null; // exact, not estimated
  if (!variant.bandwidthBitsPerSec || !durationSeconds) return null;
  return (variant.bandwidthBitsPerSec * durationSeconds) / 8;
}

function estimateSizeText(variant, durationSeconds) {
  const bytes = estimateSizeBytes(variant, durationSeconds);
  if (bytes == null) return '';
  const formatted = formatBytes(bytes);
  if (!formatted) return '';
  return variant.isOriginal ? formatted : `~${formatted}`;
}

async function loadIncludeCreatorSetting() {
  try {
    const stored = await browser.storage.local.get(STORAGE_KEY_INCLUDE_CREATOR);
    if (typeof stored[STORAGE_KEY_INCLUDE_CREATOR] === 'boolean') {
      return stored[STORAGE_KEY_INCLUDE_CREATOR];
    }
  } catch (e) {
    // storage unavailable for some reason - fall back to default
  }
  return true;
}

async function saveIncludeCreatorSetting(value) {
  try {
    await browser.storage.local.set({ [STORAGE_KEY_INCLUDE_CREATOR]: value });
  } catch (e) {
    // non-fatal - the toggle just won't be remembered next time
  }
}

async function loadIncludeUploaderSetting() {
  try {
    const stored = await browser.storage.local.get(STORAGE_KEY_INCLUDE_UPLOADER);
    if (typeof stored[STORAGE_KEY_INCLUDE_UPLOADER] === 'boolean') {
      return stored[STORAGE_KEY_INCLUDE_UPLOADER];
    }
  } catch (e) {
    // storage unavailable for some reason - fall back to default
  }
  return true;
}

async function saveIncludeUploaderSetting(value) {
  try {
    await browser.storage.local.set({ [STORAGE_KEY_INCLUDE_UPLOADER]: value });
  } catch (e) {
    // non-fatal - the toggle just won't be remembered next time
  }
}

async function loadIncludeResolutionSetting() {
  try {
    const stored = await browser.storage.local.get(STORAGE_KEY_INCLUDE_RESOLUTION);
    if (typeof stored[STORAGE_KEY_INCLUDE_RESOLUTION] === 'boolean') {
      return stored[STORAGE_KEY_INCLUDE_RESOLUTION];
    }
  } catch (e) {
    // storage unavailable for some reason - fall back to default
  }
  return true;
}

async function saveIncludeResolutionSetting(value) {
  try {
    await browser.storage.local.set({ [STORAGE_KEY_INCLUDE_RESOLUTION]: value });
  } catch (e) {
    // non-fatal - the toggle just won't be remembered next time
  }
}

async function loadDarkModeSetting() {
  try {
    const stored = await browser.storage.local.get(STORAGE_KEY_DARK_MODE);
    if (typeof stored[STORAGE_KEY_DARK_MODE] === 'boolean') {
      return stored[STORAGE_KEY_DARK_MODE];
    }
  } catch (e) {
    // storage unavailable for some reason - fall back to default
  }
  return true;
}

async function saveDarkModeSetting(value) {
  try {
    await browser.storage.local.set({ [STORAGE_KEY_DARK_MODE]: value });
  } catch (e) {
    // non-fatal - the toggle just won't be remembered next time
  }
}

function applyDarkMode(enabled) {
  document.body.classList.toggle('dark-mode', enabled);
  const btn = document.getElementById('darkModeToggle');
  // Monochrome SVGs (colored via currentColor) instead of emoji, so the
  // icon always matches the theme instead of the sun rendering yellow.
  // Cloned from a <template> (static, parsed once) rather than assigned via
  // innerHTML at runtime.
  const templateId = enabled ? 'tpl-icon-sun' : 'tpl-icon-moon';
  const iconContent = document.getElementById(templateId).content.cloneNode(true);
  btn.replaceChildren(iconContent);
  btn.title = enabled ? 'Switch to light mode' : 'Switch to dark mode';
}

function sendToBackground(type, extra) {
  return browser.runtime.sendMessage({ type, tabId: myTabId, ...extra }).catch(() => {});
}

function refreshBaseNameFromToggles() {
  if (!currentInfo) return;
  const filenameInput = document.getElementById('filenameInput');
  const newDefault = buildBaseName(currentInfo, includeCreator, includeUploader);
  // Only auto-update the field if the user hasn't typed a custom name -
  // don't clobber something they've deliberately edited.
  if (filenameInput.value === lastAutoBaseName) {
    filenameInput.value = newDefault;
  }
  lastAutoBaseName = newDefault;
}

function updateDownloadButtonState() {
  const anyChecked = Array.from(document.querySelectorAll('.res-checkbox:not(:disabled)')).some(
    (cb) => cb.checked
  );
  document.getElementById('downloadBtn').disabled = !anyChecked;
}

function syncAllCheckboxState() {
  const boxes = Array.from(document.querySelectorAll('.res-checkbox:not(:disabled)'));
  const allChecked = boxes.length > 0 && boxes.every((cb) => cb.checked);
  document.getElementById('resolutionAllToggle').checked = allChecked;
}

// ---- Per-resolution rows: checkbox <-> inline progress ----

// Creates (or returns the existing) row for a resolution label. `variantIndex`
// is set when the row corresponds to a resolution from the current master
// playlist; rows created only because background reported a download for a
// label no longer in the current list (e.g. the tab navigated to a
// different video mid-download) are left without one and are removed
// entirely once that download finishes/cancels, rather than reverting to an
// unusable checkbox.
function ensureRow(label, variantIndex) {
  let els = resolutionRows.get(label);
  if (els) {
    if (variantIndex != null) {
      els.fromVariant = true;
      els.checkbox.dataset.index = String(variantIndex);
    }
    return els;
  }

  const row = document.createElement('div');
  row.className = 'res-row';
  const rowContent = document.getElementById('tpl-res-row').content.cloneNode(true);
  row.appendChild(rowContent);

  const checkbox = row.querySelector('.res-checkbox');
  const labelEl = row.querySelector('.checkbox-row label');
  const cbId = `res-opt-${label.replace(/[^a-zA-Z0-9]+/g, '_')}`;
  checkbox.id = cbId;
  labelEl.setAttribute('for', cbId);
  labelEl.textContent = label;
  if (variantIndex != null) checkbox.dataset.index = String(variantIndex);
  checkbox.addEventListener('change', () => {
    syncAllCheckboxState();
    updateDownloadButtonState();
  });

  els = {
    label,
    fromVariant: variantIndex != null,
    row,
    checkboxRow: row.querySelector('.checkbox-row'),
    checkbox,
    checkboxResultIcon: row.querySelector('.checkbox-row .result-icon'),
    sizeEl: row.querySelector('.res-size'),
    sizeText: '', // estimated size text, shared between the checkbox row and progress card
    progress: row.querySelector('.res-progress'),
    resolutionText: row.querySelector('.dl-resolution'),
    progressSize: row.querySelector('.dl-resolution-line .dl-size'),
    progressResultIcon: row.querySelector('.dl-resolution-line .result-icon'),
    closeBtn: row.querySelector('.dl-close'),
    progressInner: row.querySelector('.dl-progress-inner'),
    percent: row.querySelector('.dl-percent'),
    speed: row.querySelector('.dl-speed'),
    status: row.querySelector('.dl-status'),
    pauseBtn: row.querySelector('.dl-pause'),
    cancelBtn: row.querySelector('.dl-cancel'),
    retryBtn: row.querySelector('.dl-retry'),
    lastState: null, // kept so Retry can restart with the same variant/filename/pageInfo
  };
  els.resolutionText.textContent = label;

  els.pauseBtn.addEventListener('click', () => {
    sendToBackground('TOGGLE_PAUSE', { resolutionLabel: label });
  });

  els.retryBtn.addEventListener('click', () => {
    const last = els.lastState;
    if (!last || !last.variant) return;
    sendToBackground('START_DOWNLOAD', {
      resolutionLabel: label,
      payload: { variant: last.variant, filename: last.filename, pageInfo: last.pageInfo },
    });
    showProgressMode(label, {
      status: 'downloading',
      isPaused: false,
      variant: last.variant,
      filename: last.filename,
      pageInfo: last.pageInfo,
      percent: 0,
      speedText: '',
      statusText: 'Starting…',
    });
  });

  els.cancelBtn.addEventListener('click', () => {
    // Optimistic: background resets/removes this immediately too, but flip
    // the row back right away so it doesn't wait on the round trip.
    sendToBackground('CANCEL_DOWNLOAD', { resolutionLabel: label });
    if (els.fromVariant) {
      showCheckboxMode(label, null);
    } else {
      removeRow(label);
    }
  });

  els.closeBtn.addEventListener('click', () => {
    const result = els.lastState && els.lastState.status;
    sendToBackground('DISMISS_DOWNLOAD', { resolutionLabel: label });
    if (els.fromVariant) {
      showCheckboxMode(label, result);
    } else {
      removeRow(label);
    }
  });

  document.getElementById('resolutionOptions').appendChild(row);
  resolutionRows.set(label, els);
  return els;
}

function updateDismissAllVisibility() {
  let anyFinishedCardVisible = false;
  resolutionRows.forEach((els) => {
    const cardVisible = els.progress.style.display === 'block';
    const isFinished = els.lastState && (els.lastState.status === 'done' || els.lastState.status === 'error');
    if (cardVisible && isFinished) anyFinishedCardVisible = true;
  });
  const btn = document.getElementById('dismissAllBtn');
  if (btn) btn.style.display = anyFinishedCardVisible ? 'inline-block' : 'none';
}

function removeRow(label) {
  const els = resolutionRows.get(label);
  if (!els) return;
  els.row.remove();
  resolutionRows.delete(label);
  updateDownloadButtonState();
  updateDismissAllVisibility();
}

function renderResultIcon(el, result) {
  if (result === 'done') {
    el.textContent = '✓';
    el.style.color = '#369d32';
    el.style.display = 'inline';
  } else if (result === 'error') {
    el.textContent = '✕';
    el.style.color = '#d1010b';
    el.style.display = 'inline';
  } else {
    el.textContent = '';
    el.style.display = 'none';
  }
}

function showCheckboxMode(label, lastResult) {
  const els = resolutionRows.get(label);
  if (!els) return;
  els.checkboxRow.style.display = 'flex';
  els.progress.style.display = 'none';
  els.checkbox.checked = false;
  els.checkbox.disabled = false;
  renderResultIcon(els.checkboxResultIcon, lastResult || null);
  syncAllCheckboxState();
  updateDownloadButtonState();
  updateDismissAllVisibility();
}

function showProgressMode(label, state) {
  const els = ensureRow(label);
  els.checkboxRow.style.display = 'none';
  els.checkbox.checked = false;
  els.checkbox.disabled = true;
  els.progress.style.display = 'block';
  els.lastState = state;

  const isActive = state.status === 'downloading';
  const isFinished = state.status === 'done' || state.status === 'error';
  const isError = state.status === 'error';

  els.progressSize.textContent = els.sizeText || '';
  els.progressInner.style.width = `${state.percent || 0}%`;
  els.percent.textContent = `${Math.round(state.percent || 0)}%`;
  renderResultIcon(els.progressResultIcon, state.status === 'done' ? 'done' : isError ? 'error' : null);
  els.speed.textContent = state.speedText || '';
  els.status.textContent = state.statusText || '';
  els.pauseBtn.textContent = state.isPaused ? '▶' : '⏸';
  els.pauseBtn.title = state.isPaused ? 'Resume' : 'Pause';

  els.pauseBtn.style.display = isActive ? 'inline-block' : 'none';
  els.cancelBtn.style.display = isActive ? 'inline-block' : 'none';
  els.retryBtn.style.display = isError ? 'inline-block' : 'none';
  els.closeBtn.style.display = isFinished ? 'inline-block' : 'none';

  els.progress.classList.toggle('finished-done', state.status === 'done');
  els.progress.classList.toggle('finished-error', isError);

  syncAllCheckboxState();
  updateDownloadButtonState();
  updateDismissAllVisibility();
}

// The normal flow: read this tab's video info via the content script, list
// real resolutions as checkbox rows, and set up the base filename field.
function setResolutionListVisible(visible) {
  document.getElementById('resolutionList').style.display = visible ? 'block' : 'none';
  document.getElementById('resolutionEmpty').style.display = visible ? 'none' : 'block';
}

// True for the bare pmvhaven.com homepage (no video page path), where it's
// expected that no video stream info exists - not worth warning about.
function isPmvHavenHomepage(urlString) {
  try {
    const u = new URL(urlString);
    if (!u.hostname.includes('pmvhaven.com')) return false;
    const path = u.pathname.replace(/\/+$/, '');
    return path === '';
  } catch (e) {
    return false;
  }
}

async function loadPageInfoAndResolutions(tab) {
  const status = document.getElementById('status');
  setResolutionListVisible(false);

  if (!tab || !tab.url || !tab.url.includes('pmvhaven.com')) {
    status.textContent = 'Open a pmvhaven.com video page first, then reopen this popup.';
    return;
  }

  let domInfo = null;
  try {
    domInfo = await browser.tabs.sendMessage(tab.id, { type: 'GET_VIDEO_INFO' });
  } catch (e) {
    status.textContent = 'Could not read the page. Try reloading the tab and trying again.';
    return;
  }

  if (!domInfo || !domInfo.masterPlaylistUrl) {
    status.textContent = isPmvHavenHomepage(tab.url)
      ? 'Open a video page on pmvhaven.com to download it.'
      : 'Could not find the video stream info on this page (the page structure may have changed).';
    return;
  }

  currentInfo = domInfo;
  document.getElementById('title').textContent = domInfo.title || '(not found)';
  document.getElementById('creator').textContent = domInfo.creator || '(not found)';
  document.getElementById('uploader').textContent = domInfo.uploader || '(not found)';

  status.textContent = 'Loading available resolutions…';
  try {
    const masterText = await fetchText(domInfo.masterPlaylistUrl);
    variants = parseMasterPlaylist(masterText, domInfo.masterPlaylistUrl);
  } catch (e) {
    status.textContent = `Could not load video info: ${e.message}`;
    return;
  }

  if (!variants.length) {
    status.textContent = 'No resolutions were found in the video stream.';
    return;
  }

  // The original upload goes first, directly under the "All" row.
  if (domInfo.original && domInfo.original.url) {
    variants.unshift(makeOriginalVariant(domInfo.original));
  }

  document.getElementById('resolutionOptions').replaceChildren();
  resolutionRows.clear();
  let totalBytes = 0;
  let haveAnySize = false;
  variants.forEach((v, i) => {
    const els = ensureRow(v.label, i);
    els.sizeText = estimateSizeText(v, domInfo.durationSeconds);
    els.sizeEl.textContent = els.sizeText;
    const bytes = estimateSizeBytes(v, domInfo.durationSeconds);
    if (bytes != null) {
      totalBytes += bytes;
      haveAnySize = true;
    }
  });
  const allSizeEl = document.getElementById('resolutionAllSize');
  const totalFormatted = haveAnySize ? formatBytes(totalBytes) : '';
  allSizeEl.textContent = totalFormatted ? `~${totalFormatted} total` : '';
  syncAllCheckboxState();
  updateDownloadButtonState();
  setResolutionListVisible(true);

  lastAutoBaseName = buildBaseName(currentInfo, includeCreator, includeUploader);
  document.getElementById('filenameInput').value = lastAutoBaseName;
  status.textContent = '';
}

async function init() {
  darkModeEnabled = await loadDarkModeSetting();
  applyDarkMode(darkModeEnabled);

  includeCreator = await loadIncludeCreatorSetting();
  includeUploader = await loadIncludeUploaderSetting();
  includeResolution = await loadIncludeResolutionSetting();
  document.getElementById('includeCreatorToggle').checked = includeCreator;
  document.getElementById('includeUploaderToggle').checked = includeUploader;
  document.getElementById('includeResolutionToggle').checked = includeResolution;

  const [tab] = await browser.tabs.query({ active: true, currentWindow: true });
  myTabId = tab ? tab.id : null;

  if (myTabId == null) {
    document.getElementById('status').textContent = 'Could not identify the current tab.';
    return;
  }

  await loadPageInfoAndResolutions(tab);

  // Switch any of this tab's already-tracked downloads straight into
  // inline progress mode (or, for a dismissed one, a persistent badge on
  // its checkbox), on top of the checkbox rows just built above.
  const response = await sendToBackground('GET_STATE_ALL');
  const items = (response && response.items) || [];
  items.forEach(({ resolutionLabel, state }) => {
    if (state.pageInfo && !currentInfo) currentInfo = state.pageInfo;
    if (state.status === 'idle') {
      if (state.lastResult) showCheckboxMode(resolutionLabel, state.lastResult);
    } else {
      showProgressMode(resolutionLabel, state);
    }
  });
}

document.getElementById('darkModeToggle').addEventListener('click', async () => {
  darkModeEnabled = !darkModeEnabled;
  applyDarkMode(darkModeEnabled);
  await saveDarkModeSetting(darkModeEnabled);
});

document.getElementById('includeCreatorToggle').addEventListener('change', async (e) => {
  includeCreator = e.target.checked;
  await saveIncludeCreatorSetting(includeCreator);
  refreshBaseNameFromToggles();
});

document.getElementById('includeUploaderToggle').addEventListener('change', async (e) => {
  includeUploader = e.target.checked;
  await saveIncludeUploaderSetting(includeUploader);
  refreshBaseNameFromToggles();
});

document.getElementById('includeResolutionToggle').addEventListener('change', async (e) => {
  includeResolution = e.target.checked;
  await saveIncludeResolutionSetting(includeResolution);
});

document.getElementById('resolutionAllToggle').addEventListener('change', (e) => {
  document.querySelectorAll('.res-checkbox:not(:disabled)').forEach((cb) => {
    cb.checked = e.target.checked;
  });
  updateDownloadButtonState();
});

document.getElementById('dismissAllBtn').addEventListener('click', () => {
  resolutionRows.forEach((els, label) => {
    const last = els.lastState;
    const isFinished = last && (last.status === 'done' || last.status === 'error');
    if (!isFinished) return;

    sendToBackground('DISMISS_DOWNLOAD', { resolutionLabel: label });
    if (els.fromVariant) {
      showCheckboxMode(label, last.status);
    } else {
      removeRow(label);
    }
  });
});

document.getElementById('downloadBtn').addEventListener('click', () => {
  const baseName = finalizeBaseName(document.getElementById('filenameInput').value);
  const selected = Array.from(document.querySelectorAll('.res-checkbox:not(:disabled)')).filter(
    (cb) => cb.checked
  );

  if (!selected.length) return;

  selected.forEach((cb) => {
    const idx = Number(cb.dataset.index);
    const variant = variants[idx];
    if (!variant) return;
    const filename = variant.isOriginal
      ? filenameForOriginal(baseName, variant, includeResolution)
      : filenameForResolution(baseName, variant.label, includeResolution);

    sendToBackground('START_DOWNLOAD', {
      resolutionLabel: variant.label,
      payload: { variant, filename, pageInfo: currentInfo },
    });

    // Optimistic: show this row's progress immediately instead of waiting
    // on the first broadcast from the background script.
    showProgressMode(variant.label, {
      status: 'downloading',
      isPaused: false,
      filename,
      percent: 0,
      speedText: '',
      statusText: 'Starting…',
    });
  });
});

// Live updates from background.js while this popup happens to be open -
// only apply the ones that belong to this popup's own tab.
browser.runtime.onMessage.addListener((msg) => {
  if (!msg || msg.type !== 'STATE_UPDATE' || msg.tabId !== myTabId) return;
  if (msg.state === null) {
    const els = resolutionRows.get(msg.resolutionLabel);
    if (els) {
      if (els.fromVariant) {
        showCheckboxMode(msg.resolutionLabel, null);
      } else {
        removeRow(msg.resolutionLabel);
      }
    }
  } else if (msg.state.status === 'idle') {
    const els = resolutionRows.get(msg.resolutionLabel);
    if (els) {
      if (els.fromVariant) {
        showCheckboxMode(msg.resolutionLabel, msg.state.lastResult);
      } else {
        removeRow(msg.resolutionLabel);
      }
    }
  } else {
    showProgressMode(msg.resolutionLabel, msg.state);
  }
});

document.addEventListener('DOMContentLoaded', init);
