// Chrome (Manifest V3) port of the Firefox extension.
//
// Differences from the Firefox build, all forced by Chrome's platform:
//  - The background is a service worker, so mux.js is loaded with
//    importScripts() (with a `window` alias, which mux.js's UMD wrapper
//    looks for) and everything uses the `chrome` namespace via the
//    `browser` alias below.
//  - Service workers have no URL.createObjectURL(), so the finished MP4
//    is parked in IndexedDB and a small offscreen document (offscreen.html)
//    turns it into a blob: URL that chrome.downloads can save.
//  - Service workers get shut down when idle, so a heartbeat keeps this one
//    alive while a download is running.
const browser = globalThis.browser || chrome;
globalThis.window = globalThis;
importScripts('vendor/mux.min.js');

// background.js
//
// Owns all actual downloading so it survives the popup closing (Firefox
// destroys the popup's JS the instant it loses focus). Downloads are keyed
// by "<tabId>::<resolutionLabel>", so a single tab can run several
// downloads at once (one per resolution the user picked) and different
// tabs never interfere with each other either.
//
// Cancellation is immediate: every in-flight fetch for a given download
// carries its own AbortController, and the moment the browser's downloads
// API has taken over (browser.downloads.download), a cancel also calls
// downloads.cancel()/removeFile() on that download id. Cancelling a
// download removes its entry entirely (rather than leaving a "cancelled"
// placeholder around) so that resolution is immediately available to
// re-download.
//
// A failing segment is retried in place, in the same download attempt, up
// to SEGMENT_MAX_ATTEMPTS times total (a single flat count - there is no
// separate "restart the whole download" layer on top of it). Once that
// count is exhausted the whole download fails outright and the manual
// Retry button becomes available.
//
// Each fetched segment is raw MPEG-TS, not MP4 - vendor/mux.min.js (see
// transmuxSegmentToParts() below) remuxes them into fragmented MP4 (fMP4)
// before saving, so the file that hits disk is a real MP4 container
// rather than TS bytes renamed to .mp4.

const SEGMENT_MAX_ATTEMPTS = 10;
// Downloaded TS bytes are flushed through mux.js in pieces of roughly this
// many bytes, rather than all at once - see the comment on
// transmuxSegmentToParts() for why: mux.js's "combined" output is really
// two separate single-track moof+mdat pairs (audio's, then video's)
// concatenated together, each spanning however much was pushed since the
// last flush. A real TS segment can span 10-20+ seconds, so flushing once
// per segment produces one big audio block followed by one big video
// block per segment - fine for very short segments, but exactly what
// broke sequential playback (VLC: no video until the audio block was
// exhausted, then no audio) for longer ones.
//
// An earlier version of this code just cut every TRANSMUX_TARGET_CHUNK_BYTES
// bytes, wherever that landed. That mostly worked but had a real, confirmed
// cost: a cut landing mid-GOP forces mux.js's GOP-fusion logic to "borrow"
// trailing frames from the previous chunk to repair it - fine for MSE (the
// browser discards the resulting overlap) but overlapping, corrupted
// decode output when the pieces are just concatenated into a file (ffmpeg
// -f null - showed real H.264 decode errors and non-monotonic DTS on a
// real downloaded file). findKeyframeBoundaries() below instead scans the
// actual H.264 bitstream for real IDR (keyframe) access units and only
// ever cuts there, so GOP-fusion never has anything to repair - this value
// is now just a MINIMUM size to accumulate before taking the next
// available keyframe cut, not the cut point itself, so there's no
// correctness downside to keeping it small.
const TRANSMUX_TARGET_CHUNK_BYTES = 200 * 1024;
const SEGMENT_RETRY_DELAY_MS = 2000;
const SAVE_START_TIMEOUT_MS = 60000;
const SAVE_COMPLETE_TIMEOUT_MS = 180000;
const KEEPALIVE_ALARM = 'pmv-downloader-keepalive';
const STORAGE_KEY_DOWNLOAD_STATES = 'downloadStatesByKey';
const KEY_SEP = '::';

// vendor/mux.min.js (loaded before this file, per manifest.json) is
// supposed to define the global `muxjs` used for remuxing below.
// Checking that up front, rather than letting every download attempt fail
// with a bare "muxjs is not defined" ReferenceError buried in a stack
// trace, means a bad or missing vendor file shows up immediately as one
// clear message in the background page's console (chrome://extensions ->
// this extension -> service worker -> Inspect) and in every download's own
// status text.
const MUXJS_MISSING_MESSAGE =
  'vendor/mux.min.js did not load the muxjs library this extension needs to ' +
  'remux downloads. Replace vendor/mux.min.js with the real mux.js UMD ' +
  'bundle (see README.md), then reload the extension.';
if (typeof muxjs === 'undefined' || !muxjs.mp4 || !muxjs.mp4.Transmuxer) {
  console.error('[PMVHaven Downloader] ' + MUXJS_MISSING_MESSAGE);
}

// "<tabId>::<resolutionLabel>" -> entry
const downloadsByKey = new Map();

function makeKey(tabId, resolutionLabel) {
  return `${tabId}${KEY_SEP}${resolutionLabel}`;
}

function tabIdFromKey(key) {
  return Number(key.split(KEY_SEP)[0]);
}

function keysForTab(tabId) {
  const prefix = `${tabId}${KEY_SEP}`;
  return Array.from(downloadsByKey.keys()).filter((k) => k.startsWith(prefix));
}

function newEntry(resolutionLabel) {
  return {
    resolutionLabel,
    status: 'downloading', // downloading | done | error | idle (idle only after a dismiss, see lastResult)
    isPaused: false,
    variant: null, // { label, url }
    filename: '',
    pageInfo: null, // { title, creator, uploader, pageUrl }
    percent: 0,
    speedText: '',
    statusText: '',
    errorMessage: '',
    lastResult: null, // 'done' | 'error' - kept after dismiss so the checkbox row can still show the outcome
    controller: null, // AbortController for whatever fetch is currently in flight
    token: 0, // bumped to invalidate a stale loop
    downloadsApiId: null, // id returned by browser.downloads.download, for cancel/removeFile
  };
}

function toClientState(entry) {
  const { controller, token, downloadsApiId, ...rest } = entry;
  return rest;
}

function delay(ms) {
  return new Promise((resolve) => setTimeout(resolve, ms));
}

// Saves a blob to disk via a native <a download> click instead of the
// WebExtension downloads API - see the comment where this is called for
// why. Background pages (declared via "scripts" rather than a service
// worker) have a full document, so this works the same way it would on
// any ordinary web page.
// Races a promise against a timeout so a call that never resolves (e.g. a
// hang starting or finishing a save) fails cleanly instead of leaving the
// UI stuck forever.
function withTimeout(promise, ms, message) {
  return Promise.race([
    promise,
    new Promise((_, reject) => setTimeout(() => reject(new Error(message)), ms)),
  ]);
}

// Resolves once the given download genuinely reaches the 'complete' state
// (rejects on 'interrupted', or after timeoutMs with no resolution either
// way) - this is what lets the UI only ever report success once a real,
// findable file exists, instead of assuming success the moment the API
// call was merely accepted.
function waitForDownloadComplete(downloadId, timeoutMs) {
  return new Promise((resolve, reject) => {
    let settled = false;

    function finish(err) {
      if (settled) return;
      settled = true;
      clearTimeout(timer);
      browser.downloads.onChanged.removeListener(listener);
      if (err) reject(err);
      else resolve();
    }

    function listener(delta) {
      if (delta.id !== downloadId || !delta.state) return;
      if (delta.state.current === 'complete') finish(null);
      else if (delta.state.current === 'interrupted') finish(new Error('Save was interrupted'));
    }

    const timer = setTimeout(() => finish(new Error('Timed out finishing the save')), timeoutMs);
    browser.downloads.onChanged.addListener(listener);

    // Cover the race where the download already finished before this
    // listener was attached.
    browser.downloads
      .search({ id: downloadId })
      .then((results) => {
        const d = results && results[0];
        if (!d) return;
        if (d.state === 'complete') finish(null);
        else if (d.state === 'interrupted') finish(new Error('Save was interrupted'));
      })
      .catch(() => {});
  });
}

function resolveUrl(base, relative) {
  return new URL(relative, base).href;
}

// Returns [{ url, duration }, ...]. `duration` comes from each segment's
// preceding #EXTINF:<seconds>, tag, e.g. `#EXTINF:6.006,` -> 6.006. This is
// what lets the saved file's duration metadata be patched to the real
// total instead of the placeholder "unknown duration" mux.js otherwise
// leaves in a fragmented MP4's init segment (see patchInitSegmentDuration).
function parseMediaPlaylist(text, baseUrl) {
  const segments = [];
  let pendingDuration = 0;
  for (const rawLine of text.split('\n')) {
    const line = rawLine.trim();
    if (!line) continue;
    if (line.startsWith('#EXTINF:')) {
      const value = parseFloat(line.slice('#EXTINF:'.length));
      pendingDuration = isFinite(value) ? value : 0;
      continue;
    }
    if (line.startsWith('#')) continue;
    segments.push({ url: resolveUrl(baseUrl, line), duration: pendingDuration });
    pendingDuration = 0;
  }
  return segments;
}

function formatSpeed(bytesPerSec) {
  if (!isFinite(bytesPerSec) || bytesPerSec <= 0) return '';
  if (bytesPerSec >= 1024 * 1024) {
    return `${(bytesPerSec / (1024 * 1024)).toFixed(1)} MB/s`;
  }
  return `${(bytesPerSec / 1024).toFixed(0)} kB/s`;
}

function persistAll() {
  const obj = {};
  for (const [key, entry] of downloadsByKey.entries()) {
    obj[key] = toClientState(entry);
  }
  browser.storage.local.set({ [STORAGE_KEY_DOWNLOAD_STATES]: obj }).catch(() => {});
}

function broadcast(tabId, resolutionLabel, state) {
  // No popup may be listening (it's closed, or open on a different tab) -
  // that's expected, not an error. `state: null` signals removal.
  browser.runtime.sendMessage({ type: 'STATE_UPDATE', tabId, resolutionLabel, state }).catch(() => {});
}

function pushUpdate(tabId, entry) {
  persistAll();
  broadcast(tabId, entry.resolutionLabel, toClientState(entry));
  refreshTabIcon(tabId);
}

function removeEntry(tabId, resolutionLabel) {
  downloadsByKey.delete(makeKey(tabId, resolutionLabel));
  persistAll();
  broadcast(tabId, resolutionLabel, null);
  refreshTabIcon(tabId);
}

let heartbeatTimer = null;

function updateKeepAlive() {
  const anyActive = Array.from(downloadsByKey.values()).some((e) => e.status === 'downloading');
  if (anyActive) {
    browser.alarms.create(KEEPALIVE_ALARM, { periodInMinutes: 0.5 });
    // Any extension API call resets the service worker's idle timer, so
    // poke one every 20s while something is downloading.
    if (!heartbeatTimer) {
      heartbeatTimer = setInterval(() => {
        browser.runtime.getPlatformInfo().catch(() => {});
      }, 20000);
    }
  } else {
    browser.alarms.clear(KEEPALIVE_ALARM);
    if (heartbeatTimer) {
      clearInterval(heartbeatTimer);
      heartbeatTimer = null;
    }
  }
}

// Registered at top level so Chrome can use it to wake this service worker
// back up if it was ever stopped.
browser.alarms.onAlarm.addListener((alarm) => {
  void alarm; // no-op: just having this fire is what keeps/wakes the event page
});

// The toolbar icon shows in color on pmvhaven.com tabs and greyscale
// everywhere else, per-tab (so different tabs can show different icon
// states as you switch between them).
const ICON_SIZES = [16, 32, 48, 96, 128];

const GREY_ICON_PATHS = ICON_SIZES.reduce((paths, size) => {
  paths[size] = `icon${size}_grey.png`;
  return paths;
}, {});

const COLOR_ICON_PATHS = ICON_SIZES.reduce((paths, size) => {
  paths[size] = `icon${size}.png`;
  return paths;
}, {});

const DONE_ICON_PATHS = ICON_SIZES.reduce((paths, size) => {
  paths[size] = `icon${size}_done.png`;
  return paths;
}, {});

const ERROR_ICON_PATHS = ICON_SIZES.reduce((paths, size) => {
  paths[size] = `icon${size}_error.png`;
  return paths;
}, {});

// What the tab's download activity says the icon should show:
//   'error' - at least one download on this tab failed (shown immediately,
//             even if others are still running, and kept until dismissed)
//   'done'  - every download on this tab has finished and at least one
//             succeeded (nothing still running, nothing failed)
//   null    - nothing to report (no downloads, still downloading, or all
//             results dismissed) -> normal color/grey icon
function downloadIconStateForTab(tabId) {
  let anyDone = false;
  let anyActive = false;
  for (const key of keysForTab(tabId)) {
    const entry = downloadsByKey.get(key);
    if (!entry) continue;
    if (entry.status === 'error') return 'error';
    if (entry.status === 'downloading') anyActive = true;
    else if (entry.status === 'done') anyDone = true;
  }
  return anyDone && !anyActive ? 'done' : null;
}

// Icon updates are serialized per tab and de-duplicated. Download progress
// calls refreshTabIcon() many times a second, and setIcon() loads its images
// asynchronously, so firing one setIcon() per tick let a stale call finish
// *after* the final green-check / red-x call and overwrite it.
// Now: only one setIcon() per tab is ever in flight, a change that arrives
// meanwhile is applied right after it (latest state wins), and nothing is
// sent when the icon the tab already shows is the right one.
//
// The green-check / red-x states get extra protection, because the browser
// sometimes fails to repaint the toolbar button right when a download ends:
//  - they are never de-duplicated (every request really calls setIcon),
//  - they are applied as decoded pixel data (imageData, preloaded below)
//    rather than as file paths, so there is no asynchronous image load that
//    can lag behind or be dropped,
//  - and they are re-applied on a schedule and whenever the tab, window or
//    browser downloads report any activity (see reassertTerminalIcons()).
const appliedIconKeyByTab = new Map(); // tabId -> 'error' | 'done' | 'grey' | 'color'
const iconQueueByTab = new Map(); // tabId -> { running, dirty, url, force }

const iconImageDataCache = { done: null, error: null };

async function loadIconImageData(paths) {
  const out = {};
  for (const size of ICON_SIZES) {
    const res = await fetch(browser.runtime.getURL(paths[size]));
    const bitmap = await createImageBitmap(await res.blob());
    const canvas = new OffscreenCanvas(size, size);
    const ctx = canvas.getContext('2d');
    ctx.drawImage(bitmap, 0, 0, size, size);
    out[size] = ctx.getImageData(0, 0, size, size);
  }
  return out;
}

(async () => {
  try {
    iconImageDataCache.done = await loadIconImageData(DONE_ICON_PATHS);
    iconImageDataCache.error = await loadIconImageData(ERROR_ICON_PATHS);
    reassertTerminalIcons();
  } catch (e) {
    // Falls back to the plain file paths - not fatal.
    console.warn('[PMVHaven Downloader] could not preload status icons:', e);
  }
})();

function resolveDesiredIcon(tabId, url) {
  // A download result (green check / red x) takes priority over the
  // color/grey page-based icon.
  const resultState = downloadIconStateForTab(tabId);
  if (resultState === 'error') {
    return { key: 'error', terminal: true, path: ERROR_ICON_PATHS, imageData: iconImageDataCache.error };
  }
  if (resultState === 'done') {
    return { key: 'done', terminal: true, path: DONE_ICON_PATHS, imageData: iconImageDataCache.done };
  }
  // Browsers may force the manifest's default icon on privileged internal
  // pages and ignore any per-tab override for them, so the default icon (in
  // manifest.json) is the color version, and this only overrides to grey for
  // tabs we can positively confirm are ordinary, non-pmvhaven websites;
  // everything else resets to that color default.
  const isOrdinaryNonPmvHavenPage =
    typeof url === 'string' && url !== '' && !/^(about|chrome|chrome-extension|edge|devtools):/.test(url) && !url.includes('pmvhaven.com');
  return isOrdinaryNonPmvHavenPage
    ? { key: 'grey', path: GREY_ICON_PATHS }
    : { key: 'color', path: COLOR_ICON_PATHS };
}

async function updateActionIcon(tabId, url, options) {
  if (tabId == null) return;
  let q = iconQueueByTab.get(tabId);
  if (!q) {
    q = { running: false, dirty: false, url, force: false };
    iconQueueByTab.set(tabId, q);
  }
  q.url = url;
  if (options && options.force) q.force = true;
  if (q.running) {
    q.dirty = true;
    return;
  }
  q.running = true;
  try {
    do {
      q.dirty = false;
      const force = q.force;
      q.force = false;
      // Decided here, at apply time, so it always reflects the latest state.
      const desired = resolveDesiredIcon(tabId, q.url);
      if (!force && !desired.terminal && appliedIconKeyByTab.get(tabId) === desired.key) continue;
      try {
        await browser.action.setIcon(
          desired.imageData ? { tabId, imageData: desired.imageData } : { tabId, path: desired.path }
        );
        appliedIconKeyByTab.set(tabId, desired.key);
      } catch (e) {
        // tab may have closed already, or the API may be unavailable - not fatal
        appliedIconKeyByTab.delete(tabId);
      }
    } while (q.dirty || q.force);
  } finally {
    q.running = false;
  }
}

// Re-evaluates one tab's icon after its downloads changed.
async function refreshTabIcon(tabId) {
  if (tabId == null || tabId < 0) return;
  try {
    const tab = await browser.tabs.get(tabId);
    updateActionIcon(tabId, tab.url);
    // For a finished/failed result, re-assert a few times shortly after in
    // case the browser repainted or reset the tab's icon right as the
    // download ended.
    if (downloadIconStateForTab(tabId)) {
      for (const ms of [150, 600, 2000, 5000]) {
        setTimeout(() => {
          if (downloadIconStateForTab(tabId)) updateActionIcon(tabId, tab.url, { force: true });
        }, ms);
      }
    }
  } catch (e) {
    // tab closed - nothing to update
  }
}

// Forces a fresh icon for every tab currently showing a finished/failed
// result. Debounced because it is triggered by chatty browser events.
let reassertTimer = null;
function reassertTerminalIcons() {
  if (reassertTimer) return;
  reassertTimer = setTimeout(async () => {
    reassertTimer = null;
    const tabIds = new Set(Array.from(downloadsByKey.keys()).map(tabIdFromKey));
    for (const tabId of tabIds) {
      if (!downloadIconStateForTab(tabId)) continue;
      try {
        const tab = await browser.tabs.get(tabId);
        updateActionIcon(tabId, tab.url, { force: true });
      } catch (e) {
        // tab closed
      }
    }
  }, 100);
}

browser.windows.onFocusChanged.addListener(reassertTerminalIcons);
browser.downloads.onCreated.addListener(reassertTerminalIcons);
browser.downloads.onChanged.addListener(reassertTerminalIcons);

browser.tabs.onActivated.addListener(async ({ tabId }) => {
  try {
    const tab = await browser.tabs.get(tabId);
    updateActionIcon(tabId, tab.url, { force: true });
  } catch (e) {
    // tab may have closed already - not fatal
  }
});

browser.tabs.onUpdated.addListener((tabId, changeInfo, tab) => {
  // Navigating clears a tab's icon override, so whatever was applied before
  // can no longer be assumed to be showing.
  if (changeInfo.url || changeInfo.status === 'loading') appliedIconKeyByTab.delete(tabId);
  if (changeInfo.url || changeInfo.status === 'complete') {
    updateActionIcon(tabId, tab.url, { force: true });
  } else if (downloadIconStateForTab(tabId)) {
    reassertTerminalIcons();
  }
});

// Set the correct icon for every already-active tab right away, since the
// listeners above only cover tab switches/navigations from this point on.
(async () => {
  try {
    const activeTabs = await browser.tabs.query({ active: true });
    for (const tab of activeTabs) {
      updateActionIcon(tab.id, tab.url);
    }
  } catch (e) {
    // not fatal - icons will still update as tabs are switched/navigated
  }
})();

// Aborts whatever this entry's currently in-flight fetch is (if any) and
// cancels/removes the file if the browser's downloads API already took over.
function hardStop(entry) {
  entry.isCancelled = true;
  if (entry.controller) {
    try {
      entry.controller.abort();
    } catch (e) {
      // ignore
    }
  }
  if (entry.downloadsApiId != null) {
    const id = entry.downloadsApiId;
    browser.downloads.cancel(id).catch(() => {});
    browser.downloads.removeFile(id).catch(() => {});
  }
}

async function fetchTextAbortable(url, entry) {
  const controller = new AbortController();
  entry.controller = controller;
  try {
    const res = await fetch(url, { signal: controller.signal });
    if (!res.ok) throw new Error(`HTTP ${res.status} loading ${url}`);
    const text = await res.text();
    entry.controller = null;
    return text;
  } catch (e) {
    entry.controller = null;
    if (e.name === 'AbortError' || entry.isCancelled) throw new Error('cancelled');
    throw e;
  }
}

async function fetchSegmentWithRetry(entry, url, index, total, onStatus) {
  let lastErr;
  for (let attempt = 1; attempt <= SEGMENT_MAX_ATTEMPTS; attempt++) {
    if (entry.isCancelled) throw new Error('cancelled');

    const controller = new AbortController();
    entry.controller = controller;
    try {
      const res = await fetch(url, { signal: controller.signal });
      if (!res.ok) throw new Error(`HTTP ${res.status}`);
      const buf = await res.arrayBuffer();
      entry.controller = null;
      return buf;
    } catch (e) {
      entry.controller = null;
      if (e.name === 'AbortError' || entry.isCancelled) throw new Error('cancelled');
      lastErr = e;
      if (attempt < SEGMENT_MAX_ATTEMPTS) {
        onStatus(`Segment ${index + 1} of ${total} failed (attempt ${attempt}/${SEGMENT_MAX_ATTEMPTS})`);
        await delay(SEGMENT_RETRY_DELAY_MS);
        if (entry.isCancelled) throw new Error('cancelled');
      }
    }
  }
  throw new Error(`Segment ${index + 1} failed after ${SEGMENT_MAX_ATTEMPTS} attempts`);
}

// --- Duration metadata patching -------------------------------------------
//
// mux.js's generated init segment (moov) is built for MSE playback, where
// the browser is told the real duration separately via
// `mediaSource.duration` - so it deliberately writes the ISO-BMFF
// "unknown duration" placeholder (all-1s, 0xFFFFFFFF) into mvhd/tkhd/mdhd.
// A standalone saved file has nowhere else to carry the real duration, so
// most players/OS file-info panels read that placeholder literally - at a
// 90kHz timescale, 0xFFFFFFFF / 90000 is ~47722s, i.e. exactly the bogus
// "13:15:2x" this extension was showing. The fix is to overwrite those
// duration fields in place with the real total (summed from the m3u8's
// #EXTINF tags) once the init segment exists, before it's saved.
//
// This walks the box tree just far enough to find mvhd/tkhd/mdhd and
// overwrites their existing duration field(s) in place - it never resizes
// or moves any box, so nothing else in the file needs to change to stay
// consistent.

// Lists this box's immediate children between byte offsets [start, end).
function readBoxes(bytes, start, end) {
  const boxes = [];
  const view = new DataView(bytes.buffer, bytes.byteOffset, bytes.byteLength);
  let offset = start;
  while (offset + 8 <= end) {
    let size = view.getUint32(offset);
    const type = String.fromCharCode(bytes[offset + 4], bytes[offset + 5], bytes[offset + 6], bytes[offset + 7]);
    let headerSize = 8;
    if (size === 1) {
      // 64-bit largesize extension - present but astronomically unlikely
      // for a moov this small; handled anyway rather than silently
      // misreading the box layout.
      const high = view.getUint32(offset + 8);
      const low = view.getUint32(offset + 12);
      size = high * 4294967296 + low;
      headerSize = 16;
    } else if (size === 0) {
      size = end - offset; // box extends to the end of its parent
    }
    if (size < headerSize) break; // malformed - bail out rather than loop forever
    boxes.push({ type, start: offset, size, payloadStart: offset + headerSize });
    offset += size;
  }
  return boxes;
}

// Shared layout of mvhd and mdhd: version+flags(4), then creation_time +
// modification_time (4+4 bytes for version 0, 8+8 for version 1), then
// timescale(4), then duration(4 or 8). Overwrites duration in place using
// this box's own timescale and returns that timescale (needed by the
// caller to convert tkhd's duration, which is expressed in the *movie*
// timescale rather than this box's own).
function patchTimescaleDurationBox(view, box, durationSeconds) {
  const version = view.getUint8(box.payloadStart);
  const afterFlags = box.payloadStart + 4;
  const timescaleOffset = afterFlags + (version === 1 ? 16 : 8);
  const durationOffset = timescaleOffset + 4;
  const timescale = view.getUint32(timescaleOffset);
  if (!timescale) return null;
  const newDuration = Math.round(durationSeconds * timescale);
  if (version === 1) {
    view.setUint32(durationOffset, Math.floor(newDuration / 4294967296));
    view.setUint32(durationOffset + 4, newDuration >>> 0);
  } else {
    view.setUint32(durationOffset, Math.min(newDuration, 0xfffffffe));
  }
  return timescale;
}

// tkhd's duration field sits after creation_time/modification_time/
// track_ID/reserved rather than right after a timescale field (tkhd has
// none - it shares the movie's), so it needs its own offset math, but the
// value written is the movie duration computed above.
function patchTkhdDuration(view, box, movieDuration) {
  const version = view.getUint8(box.payloadStart);
  const base = box.payloadStart + 4;
  const durationOffset = base + (version === 1 ? 8 + 8 + 4 + 4 : 4 + 4 + 4 + 4);
  if (version === 1) {
    view.setUint32(durationOffset, Math.floor(movieDuration / 4294967296));
    view.setUint32(durationOffset + 4, movieDuration >>> 0);
  } else {
    view.setUint32(durationOffset, Math.min(movieDuration, 0xfffffffe));
  }
}

function patchInitSegmentDuration(initSegment, durationSeconds) {
  if (!(durationSeconds > 0)) return;
  try {
    const view = new DataView(initSegment.buffer, initSegment.byteOffset, initSegment.byteLength);
    const moov = readBoxes(initSegment, 0, initSegment.length).find((b) => b.type === 'moov');
    if (!moov) return;
    const moovChildren = readBoxes(initSegment, moov.payloadStart, moov.start + moov.size);
    const mvhd = moovChildren.find((b) => b.type === 'mvhd');
    if (!mvhd) return;
    const movieTimescale = patchTimescaleDurationBox(view, mvhd, durationSeconds);
    if (!movieTimescale) return;
    const movieDuration = Math.round(durationSeconds * movieTimescale);
    for (const trak of moovChildren.filter((b) => b.type === 'trak')) {
      const trakChildren = readBoxes(initSegment, trak.payloadStart, trak.start + trak.size);
      const tkhd = trakChildren.find((b) => b.type === 'tkhd');
      if (tkhd) patchTkhdDuration(view, tkhd, movieDuration);
      const mdia = trakChildren.find((b) => b.type === 'mdia');
      if (mdia) {
        const mdhd = readBoxes(initSegment, mdia.payloadStart, mdia.start + mdia.size).find((b) => b.type === 'mdhd');
        if (mdhd) patchTimescaleDurationBox(view, mdhd, durationSeconds);
      }
    }
  } catch (e) {
    // Metadata-only: leave the placeholder in place rather than fail the
    // download over a cosmetic field.
    console.warn('[PMVHaven Downloader] Could not patch duration metadata (playback is unaffected):', e);
  }
}

// --- Audio bitrate metadata patching ---------------------------------------
//
// mux.js's generated `esds` box (the AAC decoder config, inside
// trak/mdia/minf/stbl/stsd/mp4a) hardcodes both maxBitrate and avgBitrate
// to a fixed 56000 (0x0000DAC0) regardless of the source audio's actual
// bitrate - that's the constant "56 kbps" shown for every file. Unlike the
// duration placeholder, this isn't a deliberate "ask elsewhere" design
// choice for MSE, it's just a static template value mux.js's generator
// never bothered to compute per-track. This section computes the real
// figure - from the actual number of audio sample bytes written, summed
// straight out of each fragment's own `trun` sample-size table, divided
// by the file's total duration - and overwrites those two fields in the
// exact same fixed-size, fixed-position way patchInitSegmentDuration
// overwrites mvhd/tkhd/mdhd: no box is resized or moved, only existing
// bytes change value, and only after confirming (via the ES_DescrTag /
// DecoderConfigDescrTag marker bytes mux.js's template always includes at
// those offsets) that this really is that layout - if a future mux.js
// version doesn't match, this silently does nothing rather than guess.

function readU24(view, offset) {
  return (view.getUint8(offset) << 16) | (view.getUint8(offset + 1) << 8) | view.getUint8(offset + 2);
}

function readTrackId(view, tkhd) {
  const version = view.getUint8(tkhd.payloadStart);
  const base = tkhd.payloadStart + 4;
  return view.getUint32(base + (version === 1 ? 16 : 8));
}

// Reads the moov once to find: which track_ID is the audio track (via each
// trak's mdia/hdlr handler_type, 'soun' vs 'vide'), and that audio track's
// esds box (via mdia/minf/stbl/stsd -> the sample entry's fixed 28-byte
// AudioSampleEntry header -> esds). stsd itself has its own fixed 8-byte
// (version+flags+entry_count) header before its child sample-entry boxes.
function findAudioTrackInfo(initSegment) {
  const moov = readBoxes(initSegment, 0, initSegment.length).find((b) => b.type === 'moov');
  if (!moov) return null;
  for (const trak of readBoxes(initSegment, moov.payloadStart, moov.start + moov.size).filter((b) => b.type === 'trak')) {
    const trakChildren = readBoxes(initSegment, trak.payloadStart, trak.start + trak.size);
    const tkhd = trakChildren.find((b) => b.type === 'tkhd');
    const mdia = trakChildren.find((b) => b.type === 'mdia');
    if (!tkhd || !mdia) continue;
    const mdiaChildren = readBoxes(initSegment, mdia.payloadStart, mdia.start + mdia.size);
    const hdlr = mdiaChildren.find((b) => b.type === 'hdlr');
    if (!hdlr) continue;
    const handlerType = String.fromCharCode(
      initSegment[hdlr.payloadStart + 8],
      initSegment[hdlr.payloadStart + 9],
      initSegment[hdlr.payloadStart + 10],
      initSegment[hdlr.payloadStart + 11]
    );
    if (handlerType !== 'soun') continue;

    const minf = mdiaChildren.find((b) => b.type === 'minf');
    const stbl = minf && readBoxes(initSegment, minf.payloadStart, minf.start + minf.size).find((b) => b.type === 'stbl');
    const stsd = stbl && readBoxes(initSegment, stbl.payloadStart, stbl.start + stbl.size).find((b) => b.type === 'stsd');
    if (!stsd) continue;
    const sampleEntry = readBoxes(initSegment, stsd.payloadStart + 8, stsd.start + stsd.size)[0];
    if (!sampleEntry) continue;
    const esds = readBoxes(initSegment, sampleEntry.payloadStart + 28, sampleEntry.start + sampleEntry.size).find(
      (b) => b.type === 'esds'
    );
    if (!esds) continue;

    const view = new DataView(initSegment.buffer, initSegment.byteOffset, initSegment.byteLength);
    return { trackId: readTrackId(view, tkhd), esdsBox: esds };
  }
  return null;
}

// Sums the sample sizes an audio (or any single) track contributed to one
// moof, straight from its traf/trun boxes - this is exactly how many bytes
// of that track ended up in the adjoining mdat, no need to touch mdat itself.
function sumTrackSampleBytesInMoof(bytes, moof, targetTrackId) {
  const view = new DataView(bytes.buffer, bytes.byteOffset, bytes.byteLength);
  let total = 0;
  for (const traf of readBoxes(bytes, moof.payloadStart, moof.start + moof.size).filter((b) => b.type === 'traf')) {
    const trafChildren = readBoxes(bytes, traf.payloadStart, traf.start + traf.size);
    const tfhd = trafChildren.find((b) => b.type === 'tfhd');
    const trun = trafChildren.find((b) => b.type === 'trun');
    if (!tfhd || !trun) continue;
    if (view.getUint32(tfhd.payloadStart + 4) !== targetTrackId) continue;

    const flags = readU24(view, trun.payloadStart + 1);
    const sampleCount = view.getUint32(trun.payloadStart + 4);
    const hasDataOffset = !!(flags & 0x000001);
    const hasFirstSampleFlags = !!(flags & 0x000004);
    const hasDuration = !!(flags & 0x000100);
    const hasSize = !!(flags & 0x000200);
    const hasFlags = !!(flags & 0x000400);
    const hasCto = !!(flags & 0x000800);
    if (!hasSize) continue; // nothing to sum without explicit per-sample sizes

    let offset = trun.payloadStart + 8;
    if (hasDataOffset) offset += 4;
    if (hasFirstSampleFlags) offset += 4;
    for (let i = 0; i < sampleCount; i++) {
      if (hasDuration) offset += 4;
      if (hasSize) {
        total += view.getUint32(offset);
        offset += 4;
      }
      if (hasFlags) offset += 4;
      if (hasCto) offset += 4;
    }
  }
  return total;
}

// mux.js's esds template (unchanged across the versions this was checked
// against) is a fixed-length byte array where maxBitrate and avgBitrate
// each occupy a known 4-byte slot. Confirms the two descriptor tag marker
// bytes the template always has at those fixed offsets before writing
// anything, so a differently-laid-out esds (a future mux.js version, or a
// non-AAC codec) is left untouched rather than guessed at.
function patchEsdsBitrate(initSegment, esdsBox, bitrateBps) {
  const p = esdsBox.payloadStart;
  if (initSegment[p + 4] !== 0x03 || initSegment[p + 9] !== 0x04) return false; // ES_DescrTag / DecoderConfigDescrTag
  const view = new DataView(initSegment.buffer, initSegment.byteOffset, initSegment.byteLength);
  const clamped = Math.min(Math.max(Math.round(bitrateBps), 0), 0xffffffff);
  view.setUint32(p + 16, clamped); // maxBitrate
  view.setUint32(p + 20, clamped); // avgBitrate
  return true;
}

// Computes the real average audio bitrate from the samples mux.js actually
// wrote (mp4Parts[0] is the init segment, mp4Parts[1..] are moof+mdat
// fragments) and patches it into mp4Parts[0]'s esds box in place.
function patchAudioBitrate(mp4Parts, totalDurationSeconds) {
  if (!(totalDurationSeconds > 0) || mp4Parts.length < 2) return;
  try {
    const initSegment = mp4Parts[0];
    const audioInfo = findAudioTrackInfo(initSegment);
    if (!audioInfo) return; // no audio track, or an unrecognized layout

    let totalAudioBytes = 0;
    for (let i = 1; i < mp4Parts.length; i++) {
      const part = mp4Parts[i];
      // A part can contain MORE THAN ONE top-level moof+mdat pair
      // concatenated together (see transmuxSegmentToParts's comment) -
      // scanning only the first would silently miss whichever track's
      // pair comes second.
      for (const moof of readBoxes(part, 0, part.length).filter((b) => b.type === 'moof')) {
        totalAudioBytes += sumTrackSampleBytesInMoof(part, moof, audioInfo.trackId);
      }
    }
    if (totalAudioBytes <= 0) return;

    const avgBitrateBps = (totalAudioBytes * 8) / totalDurationSeconds;
    patchEsdsBitrate(initSegment, audioInfo.esdsBox, avgBitrateBps);
  } catch (e) {
    console.warn('[PMVHaven Downloader] Could not patch audio bitrate metadata (playback is unaffected):', e);
  }
}

// --- Fragment timestamp normalization ---------------------------------------
//
// Each fragment's `tfdt` (track fragment decode time) box anchors that
// fragment's samples on the track's overall decode timeline. With
// keepOriginalTimestamps, mux.js writes the source MPEG-TS's own
// (rollover-corrected) absolute PTS/DTS values into these - which,
// especially for HLS assets, routinely start at a large arbitrary offset
// having nothing to do with the video's actual start (tens of thousands of
// seconds isn't unusual). VLC's avcodec output rejects decode timestamps
// outside a sane range relative to playback and simply fails to decode,
// which showed up as "no video, audio only" and post-seek corruption. This
// walks every fragment's tfdt across every track and finds the single
// smallest value seen anywhere (the true start of the earliest track's
// earliest fragment), then subtracts that one shared baseline from every
// tfdt, on every track - same technique as
// patchInitSegmentDuration/patchEsdsBitrate: only existing fixed-size
// fields change value, nothing is resized or moved. Using one baseline
// shared by every track (rather than zero-basing each track separately)
// is what keeps their relative timing exactly as mux.js produced it -
// including any small, genuine audio/video priming skew the source
// encoder introduced - only the huge absolute offset common to all of
// them is removed.

function readTfdtValue(view, tfdt) {
  const version = view.getUint8(tfdt.payloadStart);
  return version === 1
    ? view.getUint32(tfdt.payloadStart + 4) * 4294967296 + view.getUint32(tfdt.payloadStart + 8)
    : view.getUint32(tfdt.payloadStart + 4);
}

function writeTfdtValue(view, tfdt, value) {
  const version = view.getUint8(tfdt.payloadStart);
  if (version === 1) {
    view.setUint32(tfdt.payloadStart + 4, Math.floor(value / 4294967296));
    view.setUint32(tfdt.payloadStart + 8, value >>> 0);
  } else {
    view.setUint32(tfdt.payloadStart + 4, Math.min(Math.max(value, 0), 0xfffffffe));
  }
}

// Every trak's track_ID mapped to that track's OWN media timescale (its
// mdhd timescale - e.g. 90000 for video, 44100/48000 for audio). This
// matters because tfdt's baseMediaDecodeTime is expressed in each track's
// own timescale, not a shared one - a raw tick count from the video track
// and one from the audio track are not directly comparable numbers.
function findTrackTimescales(initSegment) {
  const view = new DataView(initSegment.buffer, initSegment.byteOffset, initSegment.byteLength);
  const timescales = new Map();
  const moov = readBoxes(initSegment, 0, initSegment.length).find((b) => b.type === 'moov');
  if (!moov) return timescales;
  for (const trak of readBoxes(initSegment, moov.payloadStart, moov.start + moov.size).filter((b) => b.type === 'trak')) {
    const trakChildren = readBoxes(initSegment, trak.payloadStart, trak.start + trak.size);
    const tkhd = trakChildren.find((b) => b.type === 'tkhd');
    const mdia = trakChildren.find((b) => b.type === 'mdia');
    if (!tkhd || !mdia) continue;
    const mdhd = readBoxes(initSegment, mdia.payloadStart, mdia.start + mdia.size).find((b) => b.type === 'mdhd');
    if (!mdhd) continue;
    const mdhdVersion = view.getUint8(mdhd.payloadStart);
    const timescale = view.getUint32(mdhd.payloadStart + 4 + (mdhdVersion === 1 ? 16 : 8));
    if (timescale) timescales.set(readTrackId(view, tkhd), timescale);
  }
  return timescales;
}

// This moof's tfdt box(es) belonging to one specific track (normally just
// one traf per track per moof, but handles more than one defensively).
function findTfdtBoxesForTrack(bytes, moof, targetTrackId) {
  const view = new DataView(bytes.buffer, bytes.byteOffset, bytes.byteLength);
  const results = [];
  for (const traf of readBoxes(bytes, moof.payloadStart, moof.start + moof.size).filter((b) => b.type === 'traf')) {
    const trafChildren = readBoxes(bytes, traf.payloadStart, traf.start + traf.size);
    const tfhd = trafChildren.find((b) => b.type === 'tfhd');
    const tfdt = trafChildren.find((b) => b.type === 'tfdt');
    if (!tfhd || !tfdt) continue;
    if (view.getUint32(tfhd.payloadStart + 4) !== targetTrackId) continue;
    results.push(tfdt);
  }
  return results;
}

function normalizeFragmentTimestamps(mp4Parts) {
  if (mp4Parts.length < 2) return;
  try {
    const initSegment = mp4Parts[0];
    const timescales = findTrackTimescales(initSegment);
    if (!timescales.size) return;

    const allEntries = []; // { view, tfdt, timescale }
    for (let i = 1; i < mp4Parts.length; i++) {
      const part = mp4Parts[i];
      const view = new DataView(part.buffer, part.byteOffset, part.byteLength);
      // A part can contain MORE THAN ONE top-level moof+mdat pair
      // concatenated together (see transmuxSegmentToParts's comment) -
      // scanning only the first would silently leave whichever track's
      // pair comes second completely unnormalized.
      for (const moof of readBoxes(part, 0, part.length).filter((b) => b.type === 'moof')) {
        for (const [trackId, timescale] of timescales) {
          for (const tfdt of findTfdtBoxesForTrack(part, moof, trackId)) {
            allEntries.push({ view, tfdt, timescale });
          }
        }
      }
    }
    if (!allEntries.length) return;

    // One shared baseline across every track (not per-track), compared in
    // seconds rather than raw ticks since each track's tfdt is in that
    // track's OWN timescale - converting to a common unit first is what
    // keeps this correct when audio and video timescales differ (which
    // they normally do). Using the earliest moment seen anywhere, in
    // seconds, and reapplying it in each track's own tick rate keeps every
    // track's timing exactly relative to the others (including any small,
    // genuine audio/video priming skew the encoder introduced) - only the
    // huge offset common to all of them, in real time, is removed.
    let baseSeconds = Infinity;
    for (const { view, tfdt, timescale } of allEntries) {
      baseSeconds = Math.min(baseSeconds, readTfdtValue(view, tfdt) / timescale);
    }
    if (!isFinite(baseSeconds) || baseSeconds === 0) return;

    for (const { view, tfdt, timescale } of allEntries) {
      const currentSeconds = readTfdtValue(view, tfdt) / timescale;
      writeTfdtValue(view, tfdt, Math.round((currentSeconds - baseSeconds) * timescale));
    }
  } catch (e) {
    console.warn(
      '[PMVHaven Downloader] Could not normalize fragment timestamps (file may show a large starting offset in some players):',
      e
    );
  }
}

// --- Fragment re-alignment (VLC playback + seeking fix) ----------------------
//
// mux.js emits, for every flush, TWO separate single-track fragments: an audio
// moof+mdat and then a video moof+mdat. Two things about that layout upset
// VLC's fragmented-MP4 demuxer (both visible in a VLC debug log of a file
// produced this way):
//
//  1. Both fragments of a pair carry the SAME mfhd sequence_number (0,0,1,1,
//     2,2...). The spec requires strictly increasing numbers, and VLC checks
//     them: every repeat logs "Fragment sequence discontinuity detected" and
//     makes VLC reset its clock (ES_OUT_RESET_PCR) and re-buffer, which is
//     heard/seen as stutter, audio drop-outs and A/V drift.
//
//  2. The audio fragment and the video fragment of a pair cover DIFFERENT time
//     spans (e.g. audio 13.3s-17.3s, video 13.4s-14.8s). VLC builds its seek
//     index from moof positions, so seeking to 13.4s lands on the VIDEO moof
//     and skips the audio moof just before it - the next audio VLC sees is
//     ~4s late, and the log fills with "buffer too late ... dropped".
//
// realignFragments() re-cuts the same, untouched H.264/AAC samples into the
// layout players expect: one moof per video GOP, holding a video traf and an
// audio traf that cover the same time span, with sequence numbers 1..N in file
// order. Only the container boxes are rewritten; sample bytes are copied
// through by reference (Blob parts), never re-encoded.

function u32be(n) {
  return [(n >>> 24) & 255, (n >>> 16) & 255, (n >>> 8) & 255, n & 255];
}

function makeBox(type, ...payloads) {
  let size = 8;
  for (const p of payloads) size += p.length;
  const out = new Uint8Array(size);
  out.set(u32be(size), 0);
  for (let i = 0; i < 4; i++) out[4 + i] = type.charCodeAt(i);
  let o = 8;
  for (const p of payloads) {
    out.set(p, o);
    o += p.length;
  }
  return out;
}

// Every track in the init segment: { id, timescale, handler: 'vide'|'soun'|... }
function findTrackInfos(initSegment) {
  const infos = [];
  const view = new DataView(initSegment.buffer, initSegment.byteOffset, initSegment.byteLength);
  const moov = readBoxes(initSegment, 0, initSegment.length).find((b) => b.type === 'moov');
  if (!moov) return infos;
  for (const trak of readBoxes(initSegment, moov.payloadStart, moov.start + moov.size).filter((b) => b.type === 'trak')) {
    const kids = readBoxes(initSegment, trak.payloadStart, trak.start + trak.size);
    const tkhd = kids.find((b) => b.type === 'tkhd');
    const mdia = kids.find((b) => b.type === 'mdia');
    if (!tkhd || !mdia) continue;
    const mkids = readBoxes(initSegment, mdia.payloadStart, mdia.start + mdia.size);
    const mdhd = mkids.find((b) => b.type === 'mdhd');
    const hdlr = mkids.find((b) => b.type === 'hdlr');
    if (!mdhd || !hdlr) continue;
    const v = view.getUint8(mdhd.payloadStart);
    infos.push({
      id: readTrackId(view, tkhd),
      timescale: view.getUint32(mdhd.payloadStart + 4 + (v === 1 ? 16 : 8)),
      handler: String.fromCharCode(
        initSegment[hdlr.payloadStart + 8], initSegment[hdlr.payloadStart + 9],
        initSegment[hdlr.payloadStart + 10], initSegment[hdlr.payloadStart + 11]
      ),
    });
  }
  return infos;
}

// Parses every moof/mdat pair in mp4Parts[1..] into per-track sample lists and
// a list of "fragment start" times taken from the primary track's own moofs.
function parseFragmentSamples(mp4Parts, trackInfos) {
  const tracks = new Map(); // id -> { samples: [], fragStarts: [] , defaultFlags }
  for (const t of trackInfos) tracks.set(t.id, { info: t, samples: [], fragStarts: [], defaultFlags: undefined });

  for (let p = 1; p < mp4Parts.length; p++) {
    const part = mp4Parts[p];
    const view = new DataView(part.buffer, part.byteOffset, part.byteLength);
    for (const moof of readBoxes(part, 0, part.length).filter((b) => b.type === 'moof')) {
      for (const traf of readBoxes(part, moof.payloadStart, moof.start + moof.size).filter((b) => b.type === 'traf')) {
        const kids = readBoxes(part, traf.payloadStart, traf.start + traf.size);
        const tfhd = kids.find((b) => b.type === 'tfhd');
        const tfdt = kids.find((b) => b.type === 'tfdt');
        if (!tfhd || !tfdt) throw new Error('traf without tfhd/tfdt');
        const tfFlags = readU24(view, tfhd.payloadStart + 1);
        if (tfFlags & 0x1) throw new Error('tfhd base-data-offset not supported');
        const trackId = view.getUint32(tfhd.payloadStart + 4);
        const track = tracks.get(trackId);
        if (!track) throw new Error('unknown track ' + trackId);

        let q = tfhd.payloadStart + 8;
        if (tfFlags & 0x2) q += 4;
        let defDur = 0, defSize = 0, defFlags = 0;
        if (tfFlags & 0x8) { defDur = view.getUint32(q); q += 4; }
        if (tfFlags & 0x10) { defSize = view.getUint32(q); q += 4; }
        if (tfFlags & 0x20) { defFlags = view.getUint32(q); q += 4; if (track.defaultFlags === undefined) track.defaultFlags = defFlags; }

        let dts = readTfdtValue(view, tfdt);
        let first = true;
        for (const trun of kids.filter((b) => b.type === 'trun')) {
          const ver = view.getUint8(trun.payloadStart);
          const fl = readU24(view, trun.payloadStart + 1);
          const count = view.getUint32(trun.payloadStart + 4);
          let o = trun.payloadStart + 8;
          let dataPos = moof.start; // base = start of the enclosing moof
          if (fl & 0x1) { dataPos += view.getInt32(o); o += 4; } else throw new Error('trun without data offset');
          let firstSampleFlags;
          if (fl & 0x4) { firstSampleFlags = view.getUint32(o); o += 4; }
          for (let i = 0; i < count; i++) {
            const dur = fl & 0x100 ? view.getUint32(o) : defDur; if (fl & 0x100) o += 4;
            const size = fl & 0x200 ? view.getUint32(o) : defSize; if (fl & 0x200) o += 4;
            let sflags = fl & 0x400 ? view.getUint32(o) : (i === 0 && firstSampleFlags !== undefined ? firstSampleFlags : defFlags);
            if (fl & 0x400) o += 4;
            let cto = 0;
            if (fl & 0x800) { cto = ver === 1 ? view.getInt32(o) : view.getUint32(o); o += 4; }
            track.samples.push({ dts, dur, size, flags: sflags, cto, buf: part, pos: dataPos });
            if (first) { track.fragStarts.push(dts); first = false; }
            dts += dur;
            dataPos += size;
          }
        }
      }
    }
  }
  return tracks;
}

function buildTfhd(trackId, defaultFlags) {
  // 0x020000 default-base-is-moof | 0x02 sample-description-index | 0x20 default-sample-flags
  const withDef = defaultFlags !== undefined;
  const flags = 0x020000 | 0x02 | (withDef ? 0x20 : 0);
  const p = new Uint8Array(4 + 4 + 4 + (withDef ? 4 : 0));
  p.set([0, (flags >>> 16) & 255, (flags >>> 8) & 255, flags & 255], 0);
  p.set(u32be(trackId), 4);
  p.set(u32be(1), 8);
  if (withDef) p.set(u32be(defaultFlags >>> 0), 12);
  return makeBox('tfhd', p);
}

function buildTfdt(value) {
  const p = new Uint8Array(12);
  p[0] = 1; // version 1: 64-bit
  p.set(u32be(Math.floor(value / 4294967296)), 4);
  p.set(u32be(value >>> 0), 8);
  return makeBox('tfdt', p);
}

// Returns { box, dataOffsetPos } - dataOffsetPos is the trun data_offset field's
// position INSIDE box, so the caller can patch it once the moof size is known.
function buildTraf(trackId, tfdtValue, samples, isVideo, defaultFlags) {
  const hasCto = isVideo && samples.some((s) => s.cto !== 0);
  const perSampleFlags = isVideo;
  const fl = 0x1 | 0x100 | 0x200 | (perSampleFlags ? 0x400 : 0) | (hasCto ? 0x800 : 0);
  const per = 8 + (perSampleFlags ? 4 : 0) + (hasCto ? 4 : 0);
  const p = new Uint8Array(12 + samples.length * per);
  const dv = new DataView(p.buffer);
  dv.setUint8(0, 0); // version 0 (cto unsigned) - mux.js never produces negative offsets
  p[1] = (fl >>> 16) & 255; p[2] = (fl >>> 8) & 255; p[3] = fl & 255;
  dv.setUint32(4, samples.length);
  dv.setInt32(8, 0); // data_offset placeholder
  let o = 12;
  for (const s of samples) {
    dv.setUint32(o, s.dur); o += 4;
    dv.setUint32(o, s.size); o += 4;
    if (perSampleFlags) { dv.setUint32(o, s.flags >>> 0); o += 4; }
    if (hasCto) { dv.setUint32(o, s.cto >>> 0); o += 4; }
  }
  const trun = makeBox('trun', p);
  const traf = makeBox('traf', buildTfhd(trackId, isVideo ? undefined : defaultFlags), buildTfdt(tfdtValue), trun);
  // trun sits at the end of traf; its data_offset field is 8(header)+8(ver/flags,count) into it
  const dataOffsetPos = traf.length - trun.length + 8 + 8;
  return { box: traf, dataOffsetPos };
}

// Groups a run of samples into as few contiguous byte views as possible.
function sampleByteViews(samples) {
  const views = [];
  let i = 0;
  while (i < samples.length) {
    const s = samples[i];
    let end = s.pos + s.size;
    let j = i + 1;
    while (j < samples.length && samples[j].buf === s.buf && samples[j].pos === end) {
      end += samples[j].size;
      j++;
    }
    views.push(s.buf.subarray(s.pos, end));
    i = j;
  }
  return views;
}

function realignFragments(mp4Parts) {
  if (mp4Parts.length < 2) return mp4Parts;
  const initSegment = mp4Parts[0];
  const trackInfos = findTrackInfos(initSegment);
  if (!trackInfos.length) throw new Error('no tracks in init segment');
  const tracks = parseFragmentSamples(mp4Parts, trackInfos);

  const video = trackInfos.find((t) => t.handler === 'vide');
  const primary = video || trackInfos[0];
  const others = trackInfos.filter((t) => t !== primary);
  const primaryTrack = tracks.get(primary.id);
  if (!primaryTrack.samples.length) throw new Error('primary track has no samples');

  // Fragment boundaries: the primary track's own (keyframe-aligned) moof starts.
  const cutTimes = primaryTrack.fragStarts.slice(); // in primary timescale, ascending
  const out = [initSegment];
  const cursor = new Map(); // track id -> next unread sample index
  for (const t of trackInfos) cursor.set(t.id, 0);

  let seq = 1;
  let primaryIdx = 0;
  for (let f = 0; f < cutTimes.length; f++) {
    const isLast = f === cutTimes.length - 1;
    const pTrack = primaryTrack;
    const pStart = primaryIdx;
    let pEnd = pStart;
    if (isLast) pEnd = pTrack.samples.length;
    else while (pEnd < pTrack.samples.length && pTrack.samples[pEnd].dts < cutTimes[f + 1]) pEnd++;
    if (pEnd === pStart) continue;
    primaryIdx = pEnd;
    const cutSeconds = isLast ? Infinity : cutTimes[f + 1] / primary.timescale;

    const trafSpecs = [];
    trafSpecs.push({ info: primary, samples: pTrack.samples.slice(pStart, pEnd), isVideo: primary.handler === 'vide' });
    for (const info of others) {
      const t = tracks.get(info.id);
      const c = cursor.get(info.id);
      let e = c;
      while (e < t.samples.length && (isLast || t.samples[e].dts / info.timescale < cutSeconds)) e++;
      cursor.set(info.id, e);
      if (e > c) trafSpecs.push({ info, samples: t.samples.slice(c, e), isVideo: info.handler === 'vide' });
    }

    const mfhd = makeBox('mfhd', new Uint8Array([0, 0, 0, 0, ...u32be(seq++)]));
    const build = () => trafSpecs.map((ts) =>
      buildTraf(ts.info.id, ts.samples[0].dts, ts.samples, ts.isVideo, tracks.get(ts.info.id).defaultFlags ?? 0x02000000));
    let trafs = build();
    const moofSize = 8 + mfhd.length + trafs.reduce((n, t) => n + t.box.length, 0);
    let dataPos = moofSize + 8; // start of mdat payload, relative to moof start
    const views = [];
    trafs.forEach((t, i) => {
      new DataView(t.box.buffer).setInt32(t.dataOffsetPos, dataPos);
      const v = sampleByteViews(trafSpecs[i].samples);
      for (const x of v) { views.push(x); dataPos += x.length; }
    });
    const moof = makeBox('moof', mfhd, ...trafs.map((t) => t.box));
    const mdatSize = 8 + views.reduce((n, v) => n + v.length, 0);
    const mdatHeader = new Uint8Array(8);
    mdatHeader.set(u32be(mdatSize), 0);
    mdatHeader.set([0x6d, 0x64, 0x61, 0x74], 4);
    out.push(moof, mdatHeader, ...views);
  }
  return out;
}

// Scans raw MPEG-TS bytes and reports byte offsets where a new video
// access unit (one video frame's worth of NAL units) begins AND that
// access unit contains an IDR slice (H.264 NAL type 5) - i.e. safe places
// to cut the stream without landing mid-GOP. State is carried across
// multiple feed() calls so a caller can process a download's segments one
// at a time without losing track of a PES packet or access unit that
// spans a segment boundary.
//
// This deliberately does NOT try to be a general TS demuxer - it only
// learns the PAT -> PMT -> video PID chain once (typical VOD content
// keeps this constant for the whole file) and only reconstructs enough
// of each video access unit's payload to check for an IDR NAL. Verified
// directly (byte-for-byte, no false positives or negatives across every
// access unit) against real MPEG-TS built from real extracted H.264/AAC
// content before being wired in here.
function createKeyframeScanner() {
  const state = {
    pmtPid: undefined,
    videoPid: undefined,
    hasPartialAu: false,
    partialAuChunks: [],
    currentAuGlobalStart: -1,
    // Absolute byte offset (across every feed() call so far) of the start
    // of the buffer passed to the CURRENT feed() call - lets returned
    // boundary offsets be meaningful across multiple feed() calls.
    consumedBytes: 0,
    leftoverBytes: new Uint8Array(0),
  };

  function concatChunks(chunks) {
    let total = 0;
    for (const c of chunks) total += c.length;
    const out = new Uint8Array(total);
    let o = 0;
    for (const c of chunks) {
      out.set(c, o);
      o += c.length;
    }
    return out;
  }

  function containsIdrNal(bytes) {
    // Scan for Annex-B start codes (00 00 01) and check each NAL's type
    // (low 5 bits of the byte right after the start code) for 5 (IDR slice).
    for (let i = 0; i + 3 < bytes.length; i++) {
      if (bytes[i] === 0 && bytes[i + 1] === 0 && bytes[i + 2] === 1) {
        const nalType = bytes[i + 3] & 0x1f;
        if (nalType === 5) return true;
        i += 2;
      }
    }
    return false;
  }

  function parsePatForPmtPid(bytes, payloadStart) {
    // pointer_field, then table_id(0x00), section starts after that.
    const pointerField = bytes[payloadStart];
    const sectionStart = payloadStart + 1 + pointerField;
    if (bytes[sectionStart] !== 0x00) return undefined;
    const sectionLength = ((bytes[sectionStart + 1] & 0x0f) << 8) | bytes[sectionStart + 2];
    const programsStart = sectionStart + 8;
    const programsEnd = sectionStart + 3 + sectionLength - 4; // minus crc32
    for (let p = programsStart; p + 4 <= programsEnd; p += 4) {
      const programNumber = (bytes[p] << 8) | bytes[p + 1];
      if (programNumber === 0) continue; // network PID entry, not a program
      const pid = ((bytes[p + 2] & 0x1f) << 8) | bytes[p + 3];
      return pid; // first program's PMT PID is enough for typical VOD content
    }
    return undefined;
  }

  function parsePmtForVideoPid(bytes, payloadStart) {
    const pointerField = bytes[payloadStart];
    const sectionStart = payloadStart + 1 + pointerField;
    if (bytes[sectionStart] !== 0x02) return undefined;
    const sectionLength = ((bytes[sectionStart + 1] & 0x0f) << 8) | bytes[sectionStart + 2];
    const programInfoLength = ((bytes[sectionStart + 10] & 0x0f) << 8) | bytes[sectionStart + 11];
    let p = sectionStart + 12 + programInfoLength;
    const sectionEnd = sectionStart + 3 + sectionLength - 4; // minus crc32
    while (p + 5 <= sectionEnd) {
      const streamType = bytes[p];
      const elementaryPid = ((bytes[p + 1] & 0x1f) << 8) | bytes[p + 2];
      const esInfoLength = ((bytes[p + 3] & 0x0f) << 8) | bytes[p + 4];
      // 0x1B = H.264, 0x24 = H.265 (not expected here, but harmless to allow)
      if (streamType === 0x1b || streamType === 0x24) {
        return elementaryPid;
      }
      p += 5 + esInfoLength;
    }
    return undefined;
  }

  // Feeds the next chunk of raw TS bytes (as fetched, in order). Returns
  // an array of ABSOLUTE byte offsets (relative to the very first byte
  // ever fed, across all calls) where a new IDR-containing access unit
  // begins. Does not report the currently in-progress access unit (the
  // one still being accumulated when this call's bytes run out) - call
  // finish() once there is no more data to get a decision on that last one.
  function feed(newBytes) {
    // Prepend any leftover bytes from the end of the previous feed() call
    // (a partial TS packet straddling the boundary between two chunks) -
    // without this, up to 187 bytes get silently dropped at every chunk
    // boundary, corrupting packet alignment for everything after it.
    const bytes = state.leftoverBytes.length
      ? concatChunks([state.leftoverBytes, newBytes])
      : newBytes;
    const boundaries = [];
    const baseOffset = state.consumedBytes; // absolute offset of bytes[0]
    let offset = 0;

    while (offset + 188 <= bytes.length) {
      if (bytes[offset] !== 0x47) {
        // Lost sync - stop processing this feed() call defensively rather
        // than misinterpret arbitrary bytes as packet headers. (Shouldn't
        // happen with well-formed TS fed packet-aligned or with partial
        // packets only at the very end, which is exactly what leftoverBytes
        // carries forward.)
        break;
      }
      const pid = ((bytes[offset + 1] & 0x1f) << 8) | bytes[offset + 2];
      const pusi = (bytes[offset + 1] & 0x40) !== 0;
      const afc = (bytes[offset + 3] >> 4) & 0x3;

      let payloadStart = offset + 4;
      if (afc === 2) {
        offset += 188;
        continue; // adaptation field only, no payload
      }
      if (afc === 3) {
        const afLen = bytes[offset + 4];
        payloadStart = offset + 5 + afLen;
      }

      if (pid === 0x0000 && state.pmtPid === undefined && pusi) {
        state.pmtPid = parsePatForPmtPid(bytes, payloadStart);
      } else if (state.pmtPid !== undefined && pid === state.pmtPid && state.videoPid === undefined && pusi) {
        const found = parsePmtForVideoPid(bytes, payloadStart);
        if (found !== undefined) state.videoPid = found;
      } else if (state.videoPid !== undefined && pid === state.videoPid) {
        if (pusi) {
          // A new access unit starts here - finalize whatever was pending.
          if (state.hasPartialAu) {
            const combined = concatChunks(state.partialAuChunks);
            if (containsIdrNal(combined)) boundaries.push(state.currentAuGlobalStart);
          }
          // PES header: 00 00 01, stream_id, PES_packet_length(2), then
          // (for video, always) flags(2) + PES_header_data_length(1),
          // then that many bytes of optional fields, THEN the NAL data.
          let nalStart = payloadStart;
          if (bytes[payloadStart] === 0 && bytes[payloadStart + 1] === 0 && bytes[payloadStart + 2] === 1) {
            const headerDataLength = bytes[payloadStart + 8];
            nalStart = payloadStart + 9 + headerDataLength;
          }
          state.partialAuChunks = [bytes.slice(Math.min(nalStart, offset + 188), offset + 188)];
          state.currentAuGlobalStart = baseOffset + offset;
          state.hasPartialAu = true;
        } else if (state.hasPartialAu) {
          state.partialAuChunks.push(bytes.slice(payloadStart, offset + 188));
        }
      }

      offset += 188;
    }

    state.leftoverBytes = bytes.slice(offset);
    state.consumedBytes = baseOffset + offset;
    return boundaries;
  }

  // Call once there is no more data coming (end of the whole download) to
  // get a final decision on whatever access unit was still in progress.
  // (Not used to pick a cut point - the very end just pushes everything
  // left regardless - only kept for completeness/possible future use.)
  function finish() {
    const boundaries = [];
    if (state.hasPartialAu) {
      const combined = concatChunks(state.partialAuChunks);
      if (containsIdrNal(combined)) boundaries.push(state.currentAuGlobalStart);
      state.hasPartialAu = false;
    }
    return boundaries;
  }

  return { feed, finish };
}

// Removes and returns exactly `byteCount` bytes from the front of
// `bufferState.chunks` (an array of Uint8Arrays, oldest-first), splitting
// a chunk if the cut falls in the middle of it. Mutates `bufferState` in
// place (including `bufferState.totalLength`).
function extractPrefixBytes(bufferState, byteCount) {
  const out = new Uint8Array(byteCount);
  let filled = 0;
  while (filled < byteCount) {
    const chunk = bufferState.chunks[0];
    const needed = byteCount - filled;
    if (chunk.length <= needed) {
      out.set(chunk, filled);
      filled += chunk.length;
      bufferState.chunks.shift();
    } else {
      out.set(chunk.subarray(0, needed), filled);
      bufferState.chunks[0] = chunk.subarray(needed);
      filled += needed;
    }
  }
  bufferState.totalLength -= byteCount;
  return out;
}

// Feeds one chunk of raw MPEG-TS bytes through mux.js and returns the
// fMP4 pieces it produced (an initSegment only the very first time, per
// `state.needsInitSegment`, then always a moof+mdat pair - sometimes two
// pairs, see below).
//
// This is called once per keyframe-aligned piece the download loop cuts
// (see createKeyframeScanner above and TRANSMUX_TARGET_CHUNK_BYTES near
// the top of this file), not once per whole downloaded segment -
// confirmed directly against the real mux.js library (fed real extracted
// H.264/AAC content repackaged as MPEG-TS) that its "combined" output is
// NOT one moof with two track fragments: it's two complete, separate
// single-track moof+mdat pairs (audio's, then video's) concatenated
// together, each spanning however much was pushed since the previous
// flush. A real TS segment can span 10-20+ seconds, so flushing once per
// segment (an earlier version of this code did exactly that) produces one
// big audio-only block followed by one big video-only block per segment -
// exactly what broke sequential playback (VLC: no video until the audio
// block was exhausted, then no audio once past it, plus corruption on
// seeking). Flushing in smaller pieces instead produces many small,
// closely-spaced audio+video pairs throughout the file - but only cutting
// at real keyframes (rather than an arbitrary byte offset, which a
// still-earlier version of this code did) avoids a further, confirmed
// problem: a cut mid-GOP forces mux.js's GOP-fusion logic to duplicate
// frames to repair it, which showed up as real H.264 decode errors in a
// downloaded file. See TRANSMUX_TARGET_CHUNK_BYTES's comment for more.
function transmuxSegmentToParts(transmuxer, tsBytes, state) {
  const parts = [];
  const onData = (segment) => {
    if (state.needsInitSegment) {
      parts.push(segment.initSegment);
      state.needsInitSegment = false;
    }
    parts.push(segment.data);
  };
  transmuxer.on('data', onData);
  try {
    transmuxer.push(tsBytes);
    transmuxer.flush();
  } finally {
    transmuxer.off('data', onData);
  }
  return parts;
}

async function runDownloadAttempt(tabId, entry, myToken) {
  const variantText = await fetchTextAbortable(entry.variant.url, entry);
  if (entry.isCancelled || entry.token !== myToken) throw new Error('cancelled');

  const segments = parseMediaPlaylist(variantText, entry.variant.url);
  if (!segments.length) {
    throw new Error('No video segments were listed for this resolution');
  }
  const totalDurationSeconds = segments.reduce((sum, s) => sum + (s.duration || 0), 0);

  // keepOriginalTimestamps: true tells mux.js to use the source MPEG-TS's
  // own (rollover-corrected) PTS/DTS values as-is rather than resetting
  // each flush's timestamps to start at 0 - without it, every one of
  // these per-segment flush() calls would restart its own local zero
  // point, breaking continuity across segments the moment they're
  // concatenated into one file. The raw values this preserves routinely
  // start at a large arbitrary offset (a known HLS packaging quirk), which
  // is what normalizeFragmentTimestamps() below corrects afterward,
  // deterministically, across every fragment at once.
  const transmuxer = new muxjs.mp4.Transmuxer({ keepOriginalTimestamps: true });
  const initSegmentState = { needsInitSegment: true };
  const mp4Parts = [];

  // Bytes fetched but not yet pushed into the transmuxer, plus the running
  // keyframe scanner used to decide where it's safe to cut them (see
  // TRANSMUX_TARGET_CHUNK_BYTES's comment and createKeyframeScanner above).
  const pendingBytes = { chunks: [], totalLength: 0 };
  let pushedBytesTotal = 0; // absolute offset marking the start of pendingBytes
  const pendingKeyframeOffsets = [];
  const keyframeScanner = createKeyframeScanner();

  // Pushes+flushes exactly `byteCount` bytes from the front of
  // pendingBytes into the transmuxer, advancing pushedBytesTotal to match.
  function transmuxPendingPrefix(byteCount) {
    const chunk = extractPrefixBytes(pendingBytes, byteCount);
    const parts = transmuxSegmentToParts(transmuxer, chunk, initSegmentState);
    for (const part of parts) mp4Parts.push(part);
    pushedBytesTotal += byteCount;
  }

  // Cuts at the next available keyframe boundary that's at least
  // TRANSMUX_TARGET_CHUNK_BYTES past the last cut, if one exists yet -
  // searching forward through pendingKeyframeOffsets (which arrive in
  // increasing order) rather than only ever checking the earliest one,
  // since that one (typically very close to the previous cut) will almost
  // never itself clear the threshold even once a later one does. Removes
  // every offset up to and including the one it cuts at - the skipped
  // earlier ones are superseded, already covered by this same cut.
  // Returns true if it cut (so the caller can keep trying for more).
  function tryCutAtNextQualifyingKeyframe() {
    for (let idx = 0; idx < pendingKeyframeOffsets.length; idx++) {
      const candidate = pendingKeyframeOffsets[idx];
      if (candidate - pushedBytesTotal >= TRANSMUX_TARGET_CHUNK_BYTES) {
        pendingKeyframeOffsets.splice(0, idx + 1);
        transmuxPendingPrefix(candidate - pushedBytesTotal);
        return true;
      }
    }
    return false;
  }

  for (let i = 0; i < segments.length; i++) {
    // Poll rather than block on an unresolved promise - keeps this event
    // page demonstrably "active" while paused, and lets a cancel land
    // within one poll tick instead of waiting on an unrelated fetch.
    while (entry.isPaused) {
      if (entry.isCancelled) throw new Error('cancelled');
      entry.statusText = 'Paused.';
      pushUpdate(tabId, entry);
      await delay(400);
    }
    if (entry.isCancelled || entry.token !== myToken) throw new Error('cancelled');

    const segStart = Date.now();
    const buf = await fetchSegmentWithRetry(entry, segments[i].url, i, segments.length, (msg) => {
      entry.statusText = msg;
      broadcast(tabId, entry.resolutionLabel, toClientState(entry));
    });
    const segSeconds = (Date.now() - segStart) / 1000;

    if (entry.isCancelled || entry.token !== myToken) throw new Error('cancelled');

    // Queue this segment's bytes and scan them for real keyframe (IDR)
    // access-unit boundaries, then push+flush everything up to the next
    // available one past TRANSMUX_TARGET_CHUNK_BYTES - never at an
    // arbitrary byte offset. See TRANSMUX_TARGET_CHUNK_BYTES's comment for
    // why this matters. Unlike a simple per-segment push, `buf` can't be
    // freed the moment this iteration ends - it stays referenced via
    // pendingBytes.chunks until enough of it has been queued past a real
    // keyframe to flush, which is normally within a segment or two.
    const segmentBytes = new Uint8Array(buf);
    try {
      pendingBytes.chunks.push(segmentBytes);
      pendingBytes.totalLength += segmentBytes.length;
      for (const offset of keyframeScanner.feed(segmentBytes)) {
        pendingKeyframeOffsets.push(offset);
      }
      while (tryCutAtNextQualifyingKeyframe()) {
        // keep cutting - a segment carrying several eligible keyframes
        // (e.g. after a stretch of very short GOPs) can clear more than
        // one target-sized piece at once.
      }
    } catch (e) {
      throw new Error(`Segment ${i + 1} could not be remuxed: ${e.message || e}`);
    }
    const speed = segSeconds > 0 ? buf.byteLength / segSeconds : 0;

    entry.percent = ((i + 1) / segments.length) * 100;
    entry.speedText = formatSpeed(speed);
    entry.statusText = `Downloading segment ${i + 1} of ${segments.length}…`;
    pushUpdate(tabId, entry);
  }

  if (entry.isCancelled || entry.token !== myToken) throw new Error('cancelled');

  // Whatever's left after the loop (the tail end of the video, since
  // there's no "next" keyframe to align a final cut to) is pushed as one
  // last piece regardless of size.
  if (pendingBytes.totalLength > 0) {
    try {
      transmuxPendingPrefix(pendingBytes.totalLength);
    } catch (e) {
      throw new Error(`The final segment could not be remuxed: ${e.message || e}`);
    }
  }

  if (!mp4Parts.length) {
    throw new Error('Remuxing produced no output - the source stream may be unsupported or corrupt');
  }

  entry.statusText = 'Remuxing…';
  broadcast(tabId, entry.resolutionLabel, toClientState(entry));

  // Metadata patches, applied once as a pass over the fully-collected
  // output - each is independent of how many fragments there are or how
  // they were produced, so this works the same whether mp4Parts came from
  // many small per-segment fragments (the current, correct approach) or
  // would-be fewer/larger ones.
  patchInitSegmentDuration(mp4Parts[0], totalDurationSeconds);
  normalizeFragmentTimestamps(mp4Parts);
  patchAudioBitrate(mp4Parts, totalDurationSeconds);

  // Re-cut mux.js's separate audio-only / video-only fragments into
  // time-aligned audio+video fragments with strictly increasing sequence
  // numbers (see realignFragments's comment - this is what VLC needs to play
  // and seek the file cleanly). If anything about the layout is unexpected,
  // fall back to the original parts rather than failing the download.
  let finalParts = mp4Parts;
  try {
    finalParts = realignFragments(mp4Parts);
  } catch (e) {
    console.warn('[PMVHaven Downloader] Could not re-align fragments; saving mux.js output as-is:', e);
  }

  entry.statusText = 'Assembling file…';
  broadcast(tabId, entry.resolutionLabel, toClientState(entry));

  const blob = new Blob(finalParts, { type: 'video/mp4' });

  if (entry.isCancelled || entry.token !== myToken) throw new Error('cancelled');

  entry.statusText = 'Saving file…';
  broadcast(tabId, entry.resolutionLabel, toClientState(entry));

  await saveBlob(tabId, entry, blob, entry.filename);
}

// ---- saving -------------------------------------------------------------
// The MP4 is handed to the offscreen document through IndexedDB (the same
// extension origin is shared by both), which creates a blob: URL for it.

const BLOB_DB_NAME = 'pmv-downloader-blobs';
const BLOB_STORE = 'blobs';

function openBlobDb() {
  return new Promise((resolve, reject) => {
    const req = indexedDB.open(BLOB_DB_NAME, 1);
    req.onupgradeneeded = () => req.result.createObjectStore(BLOB_STORE);
    req.onsuccess = () => resolve(req.result);
    req.onerror = () => reject(req.error);
  });
}

async function blobDbPut(key, blob) {
  const db = await openBlobDb();
  try {
    await new Promise((resolve, reject) => {
      const tx = db.transaction(BLOB_STORE, 'readwrite');
      tx.objectStore(BLOB_STORE).put(blob, key);
      tx.oncomplete = () => resolve();
      tx.onerror = () => reject(tx.error);
      tx.onabort = () => reject(tx.error || new Error('Could not stage the file for saving'));
    });
  } finally {
    db.close();
  }
}

async function ensureOffscreenDocument() {
  const existing = await browser.runtime.getContexts({ contextTypes: ['OFFSCREEN_DOCUMENT'] });
  if (existing && existing.length) return;
  try {
    await browser.offscreen.createDocument({
      url: 'offscreen.html',
      reasons: ['BLOBS'],
      justification: 'Create a blob: URL for the remuxed MP4 so it can be saved with the downloads API.',
    });
  } catch (e) {
    if (!/single offscreen|already exists/i.test(String(e && e.message))) throw e;
  }
}

async function offscreenCall(msg) {
  const res = await browser.runtime.sendMessage({ target: 'offscreen', ...msg });
  if (!res || !res.ok) throw new Error((res && res.error) || 'Offscreen document did not respond');
  return res;
}

async function saveBlob(tabId, entry, blob, filename) {
  const blobKey = `${Date.now()}-${Math.random().toString(36).slice(2)}`;
  await blobDbPut(blobKey, blob);
  let blobUrl = null;
  try {
    await ensureOffscreenDocument();
    ({ url: blobUrl } = await offscreenCall({ type: 'MAKE_BLOB_URL', key: blobKey }));

    const downloadId = await withTimeout(
      browser.downloads.download({ url: blobUrl, filename, saveAs: false }),
      SAVE_START_TIMEOUT_MS,
      'Timed out starting the save'
    );
    entry.downloadsApiId = downloadId;

    if (entry.isCancelled) {
      browser.downloads.cancel(downloadId).catch(() => {});
      browser.downloads.removeFile(downloadId).catch(() => {});
      throw new Error('cancelled');
    }

    entry.statusText = 'Finishing save…';
    broadcast(tabId, entry.resolutionLabel, toClientState(entry));
    await waitForDownloadComplete(downloadId, SAVE_COMPLETE_TIMEOUT_MS);
  } finally {
    // Free the blob URL and the staged copy whether or not the save worked.
    offscreenCall({ type: 'RELEASE_BLOB', key: blobKey, url: blobUrl }).catch(() => {});
  }
}

// The original, non-transcoded file is a plain file URL (not an HLS stream),
// so there is nothing to remux: hand it straight to the browser's download
// manager (which streams it to disk instead of buffering it in memory) and
// mirror that download's progress into this entry.
async function runOriginalDownload(tabId, entry, myToken) {
  entry.statusText = 'Starting…';
  pushUpdate(tabId, entry);

  const id = await browser.downloads.download({
    url: entry.variant.url,
    filename: entry.filename,
    saveAs: false,
    conflictAction: 'uniquify',
  });
  entry.downloadsApiId = id;
  if (entry.isCancelled || entry.token !== myToken) {
    browser.downloads.cancel(id).catch(() => {});
    browser.downloads.removeFile(id).catch(() => {});
    throw new Error('cancelled');
  }

  let lastBytes = 0;
  let lastTime = Date.now();
  let speed = 0;
  for (;;) {
    await delay(500);
    if (entry.isCancelled || entry.token !== myToken) throw new Error('cancelled');

    const results = await browser.downloads.search({ id });
    const d = results && results[0];
    if (!d) throw new Error('The download was removed');
    if (d.state === 'complete') return;
    if (d.state === 'interrupted') {
      throw new Error(`Download interrupted${d.error ? ` (${d.error})` : ''}`);
    }

    const total = d.totalBytes > 0 ? d.totalBytes : entry.variant.fileSize || 0;
    const received = d.bytesReceived || 0;
    const now = Date.now();
    if (now - lastTime >= 500) {
      const instant = ((received - lastBytes) * 1000) / (now - lastTime);
      speed = speed ? speed * 0.7 + instant * 0.3 : instant;
      lastBytes = received;
      lastTime = now;
    }
    entry.isPaused = !!d.paused;
    entry.percent = total > 0 ? Math.min(99, (received / total) * 100) : 0;
    entry.speedText = d.paused ? '' : formatSpeed(speed);
    entry.statusText = d.paused ? 'Paused' : 'Downloading…';
    pushUpdate(tabId, entry);
  }
}

async function startDownload(tabId, resolutionLabel, payload) {
  const key = makeKey(tabId, resolutionLabel);
  let entry = downloadsByKey.get(key);
  if (!entry) {
    entry = newEntry(resolutionLabel);
    downloadsByKey.set(key, entry);
  }

  entry.isCancelled = false;
  entry.isPaused = false;
  entry.controller = null;
  entry.downloadsApiId = null;
  const myToken = ++entry.token;

  entry.status = 'downloading';
  entry.variant = payload.variant;
  entry.filename = payload.filename;
  entry.pageInfo = payload.pageInfo || null;
  entry.percent = 0;
  entry.speedText = '';
  entry.statusText = 'Loading segment list…';
  entry.errorMessage = '';

  pushUpdate(tabId, entry);
  updateKeepAlive();

  try {
    if (entry.variant && entry.variant.isOriginal) {
      await runOriginalDownload(tabId, entry, myToken);
    } else {
      if (typeof muxjs === 'undefined' || !muxjs.mp4 || !muxjs.mp4.Transmuxer) {
        throw new Error(MUXJS_MISSING_MESSAGE);
      }
      await runDownloadAttempt(tabId, entry, myToken);
    }
    if (entry.token !== myToken) return;
    entry.status = 'done';
    entry.statusText = 'Download concluded';
    entry.percent = 100;
    entry.speedText = '';
  } catch (e) {
    if (entry.token !== myToken) return;

    if (e.message === 'cancelled') {
      // The CANCEL_DOWNLOAD handler already removed this entry - nothing
      // more to do here.
      return;
    }

    entry.status = 'error';
    entry.statusText = /^Segment \d+ failed after \d+ attempts$/.test(e.message)
      ? `Download failed after ${SEGMENT_MAX_ATTEMPTS} attempts`
      : `Download failed: ${e.message}`;
    entry.errorMessage = e.message;
  }

  entry.isPaused = false;
  entry.controller = null;
  pushUpdate(tabId, entry);
  updateKeepAlive();
}

// Recover gracefully if this event page was ever unloaded mid-download by
// the browser and just got restarted - we can't resume an in-flight fetch
// loop, so say so clearly instead of showing a permanently "stuck" state.
(async () => {
  try {
    const stored = await browser.storage.local.get(STORAGE_KEY_DOWNLOAD_STATES);
    const saved = (stored && stored[STORAGE_KEY_DOWNLOAD_STATES]) || {};
    for (const [key, savedState] of Object.entries(saved)) {
      const entry = newEntry(savedState.resolutionLabel);
      if (savedState.status === 'downloading') {
        Object.assign(entry, savedState, {
          status: 'error',
          isPaused: false,
          statusText: 'Download was interrupted. Please try again.',
          speedText: '',
        });
      } else {
        Object.assign(entry, savedState);
      }
      downloadsByKey.set(key, entry);
    }
    persistAll();
  } catch (e) {
    // storage unavailable - just start with nothing recovered
  }
})();

// Clean up entries for tabs that no longer exist. A download still in
// progress is left alone - it keeps running and saving the file regardless
// of whether its originating tab is still open.
browser.tabs.onRemoved.addListener((tabId) => {
  appliedIconKeyByTab.delete(tabId);
  iconQueueByTab.delete(tabId);
  let changed = false;
  for (const key of keysForTab(tabId)) {
    const entry = downloadsByKey.get(key);
    if (entry && entry.status !== 'downloading') {
      downloadsByKey.delete(key);
      changed = true;
    }
  }
  if (changed) persistAll();
});

browser.runtime.onMessage.addListener((msg, _sender, sendResponse) => {
  if (!msg || !msg.type) return false;
  const tabId = msg.tabId;

  switch (msg.type) {
    case 'START_DOWNLOAD':
      startDownload(tabId, msg.resolutionLabel, msg.payload);
      sendResponse({ ok: true });
      return false;

    case 'TOGGLE_PAUSE': {
      const entry = downloadsByKey.get(makeKey(tabId, msg.resolutionLabel));
      if (entry && entry.status === 'downloading') {
        entry.isPaused = !entry.isPaused;
        if (!entry.isPaused) entry.statusText = 'Resuming…';
        // The original is saved by the browser's own download manager, so
        // pausing means pausing that download.
        if (entry.variant && entry.variant.isOriginal && entry.downloadsApiId != null) {
          const op = entry.isPaused ? 'pause' : 'resume';
          browser.downloads[op](entry.downloadsApiId).catch(() => {});
        }
        pushUpdate(tabId, entry);
      }
      sendResponse({ ok: true, isPaused: entry ? entry.isPaused : false });
      return false;
    }

    case 'CANCEL_DOWNLOAD': {
      const entry = downloadsByKey.get(makeKey(tabId, msg.resolutionLabel));
      if (entry && entry.status === 'downloading') {
        hardStop(entry);
        entry.token++; // invalidate the running loop so it can't recreate this entry
        removeEntry(tabId, msg.resolutionLabel); // ready for a new download of this resolution right away
        updateKeepAlive();
      }
      sendResponse({ ok: true });
      return false;
    }

    case 'DISMISS_DOWNLOAD': {
      const entry = downloadsByKey.get(makeKey(tabId, msg.resolutionLabel));
      if (entry && (entry.status === 'done' || entry.status === 'error')) {
        entry.lastResult = entry.status; // remember the outcome even after the card is gone
        entry.status = 'idle';
        entry.isPaused = false;
        entry.percent = 0;
        entry.speedText = '';
        entry.statusText = '';
        entry.controller = null;
        entry.downloadsApiId = null;
        pushUpdate(tabId, entry);
      }
      sendResponse({ ok: true });
      return false;
    }

    case 'GET_STATE_ALL': {
      const items = keysForTab(tabId).map((key) => {
        const entry = downloadsByKey.get(key);
        return { resolutionLabel: entry.resolutionLabel, state: toClientState(entry) };
      });
      sendResponse({ items });
      return false;
    }

    default:
      return false;
  }
});
