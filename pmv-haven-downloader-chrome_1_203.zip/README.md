# PMVHaven Downloader (Chrome extension, Manifest V3)

Chrome port of the Firefox build (same version, same features). Load it via
`chrome://extensions` -> Developer mode -> Load unpacked. Chrome-specific
parts: background runs as a service worker (mux.js via `importScripts`),
and `offscreen.html`/`offscreen.js` create the blob URL used to save the
finished MP4. Requires Chrome 116 or newer.

(Original Firefox README follows.)

# PMVHaven Downloader (Firefox extension)

Lets you download the video on a pmvhaven.com page, pick one or more
resolutions from a checkbox list, edit the suggested filename if you want,
and watch a live progress readout per download (with speed and
pause/cancel controls) right in place of the resolution's checkbox — the
popup never switches to a different screen. The resolution is appended to
each file's name automatically. Downloads keep running even if you close
the popup, switch tabs, or click elsewhere - see "Downloads survive the
popup closing" below - and you can run several at once, whether that's
multiple resolutions of the same video or downloads in different tabs; see
"Multiple simultaneous downloads" below.

## Creator vs. uploader

The suggested base filename is:

```
<Title> - <Creator> - up by <Uploader>.mp4
```

(any piece that can't be found, that's toggled off, or that's identical to
the creator, is skipped — most PMVs have the creator and uploader as the
same account, so most base names end up as just `<Title> - <Username>.mp4`
with no "up by" part at all.)

pmvhaven sometimes distinguishes them: an account can upload someone else's
edit and credit the original creator separately. When that happens the page
shows an "Uploader" badge on the account plus a separate "Original Creator:"
line. The extension reads the DOM directly (not the page's JSON-LD, which
mislabels the uploader as `"creator"` in that structured data) to get this
right — see the comments in `content.js` for how it tells the two apart.

You can edit the base filename field before downloading if you'd rather
name it something else — whatever you type there, each selected
resolution's file is still saved as `<your text> - <resolution>.mp4` (see
"Selecting resolutions and the filename" below).

### Toggling creator/uploader in the filename

Creator and Uploader are shown side by side in the popup, each with its own
**"Include in filename"** checkbox directly underneath it. Turn either off
to leave that piece out of the base filename — e.g. uncheck Uploader for
just `<Title> - <Creator>`, or uncheck both for just `<Title>`. Both choices
are saved independently (via `browser.storage.local`) and reused
automatically for every future download, so you only need to set them once.
Toggling either one only rewrites the filename field if you haven't already
typed a custom base name — it won't overwrite an edit you've made.

### Selecting resolutions and the filename

The Resolution section is a checkbox list — check as many resolutions as
you want, or check **All** at the top to select (or deselect) every listed
resolution at once. Clicking **Download selected** starts one download per
checked resolution, all running at the same time.

Under the Resolution heading is its own **"Include in filename"** toggle,
same idea as the Creator/Uploader ones. With it on (the default), each
file's resolution is appended automatically:

```
<base filename> - <resolution>.mp4
```

For example, a base of `My Video - Creator` with 1080p and 720p both
checked produces `My Video - Creator - 1080p.mp4` and
`My Video - Creator - 720p.mp4`. Turn it off and every file uses just
`<base filename>.mp4` instead — note that if you do this while downloading
more than one resolution at once, the files will have identical names and
your browser will disambiguate them (e.g. appending "(1)") when saving.
This choice is saved the same way as the other toggles and reused for
future downloads until changed again.

Each resolution also shows an approximate file size (e.g. `~245 MB`)
immediately after its name — both in the checkbox list and, once you start
downloading, in that resolution's progress card too — so you can judge
before and during a download. The **All** checkbox shows the combined
total across every listed resolution the same way (e.g. `~1.2 GB total`).
These are estimates — calculated from the playlist's advertised bitrate
and the video's duration, not an exact byte count — so actual file size
may differ slightly. If the page doesn't expose a duration, no size is
shown for that video.

## How it actually works

pmvhaven doesn't serve a plain downloadable `.mp4` file to logged-out users —
the "Download" button on the page is gated behind sign-in. What the page
*does* expose publicly is:

1. A `<script type="application/ld+json">` block with the video's title,
   creator, and the URL of its **HLS master playlist** (a `.m3u8` file).
2. That master playlist lists one `.m3u8` variant per resolution
   (e.g. 1080p, 720p, 480p, 360p).
3. Each resolution's playlist lists a sequence of `.ts` video segment files.

The popup fetches the master playlist to show you real resolution choices.
Clicking Download selected hands each checked resolution's variant and
filename off to the extension's background script, which fetches every
segment for that resolution, concatenates them in order, and hands the
result to the pmvhaven.com tab it started from, which saves it via a
native `<a download>` click — one such run per resolution you checked, all
in parallel. See "How downloads are saved" below for why it works this
way.

Each segment's raw MPEG-TS bytes are remuxed into a real fragmented MP4
container (`vendor/mux.min.js`, see below) before being saved — the
H.264/AAC data itself is copied through untouched (no re-encoding, no
quality loss), only the container is rebuilt, so the saved file is a
genuine `.mp4` rather than TS bytes wearing an `.mp4` extension.

Getting this right took a few iterations, verified each time by feeding
real extracted video/audio through the actual mux.js library and checking
the output with `ffmpeg -f null -` (not just inspecting the container
structure): mux.js's "combined" output turns out to be two separate
single-track fragments (audio's, then video's) concatenated together
rather than one interleaved fragment, and cutting between fragments at an
arbitrary byte offset — rather than on a real H.264 keyframe — forces its
GOP-repair logic to duplicate frames, which showed up as actual decode
errors. `background.js` scans the real bitstream for keyframe (IDR)
access units itself and only ever cuts there, so every downloaded segment
ends up as many small, correctly-interleaved audio/video fragments
instead of one giant block per track. Duration, per-track bitrate, and
fragment timestamps are also patched afterward to real, computed values —
mux.js's own defaults for these are placeholders meant for MSE playback,
not a standalone file (see the comments in `background.js` above
`patchInitSegmentDuration`, `patchAudioBitrate`, and
`normalizeFragmentTimestamps` for the specifics of each).

### Fragment re-alignment (VLC playback and seeking)

mux.js writes each flush as a separate audio-only moof followed by a
video-only moof, and both carry the same `mfhd` sequence number. VLC logs
`Fragment sequence discontinuity detected` for every repeat and resets its
clock and re-buffers each time, and because its seek index is built from
moof positions, seeking lands on a video moof and skips the audio moof just
before it (audio then resumes seconds late; the log fills with
`buffer too late ... dropped`). After the metadata patches above,
`realignFragments()` in `background.js` re-cuts the same samples into one
moof per video GOP containing both a video and an audio track fragment
covering the same time span, numbered 1..N in file order. Sample bytes are
passed through by reference (no re-encode, no extra copy). If the layout is
ever unexpected it logs a warning and saves mux.js's output unchanged.

### The `vendor/mux.min.js` file

This extension uses [mux.js](https://github.com/videojs/mux.js)
(Apache-2.0, Brightcove/videojs) to do that remuxing, via the
`muxjs.mp4.Transmuxer` API used in `background.js`. The real bundle
(v6.3.0) ships with this copy of the extension, so no setup step is
needed — if you ever need to update it, replace `vendor/mux.min.js` with
a newer build (e.g. `npm install mux.js` and copy
`node_modules/mux.js/dist/mux.min.js`) and reload the extension.

### How downloads are saved

Saving a large blob-based file from an extension's **background page** is a
long-standing source of bugs in Firefox on Android specifically — it can
fail outright or hang indefinitely with no way to detect it (this is
tracked upstream in Mozilla Bugzilla, e.g. issues #1696174, #1271345,
#1420419). Mozilla's own documented workaround is to trigger the save
from a real page instead, so that's what happens **on Android**: once a
resolution's segments are all fetched and assembled, the finished file is
handed to the pmvhaven.com tab it was started from, and that tab's content
script saves it via a native `<a download>` click — the same mechanism any
ordinary website's "click to download" link relies on.

**On desktop**, the background page saves the file directly via Firefox's
own downloads API instead — the platform-specific bug above hasn't been
observed there, so the simpler, more direct method is used rather than
routing through a content script.

On Android, this means **the tab a download was started from needs to stay
open** until that download finishes. If it's closed first, the extension
falls back to saving via Firefox's own downloads API instead, which is
less reliable for this specific case but better than not attempting a save
at all. Desktop downloads don't have this requirement, since they never
route through a content script in the first place.

One honest limitation on Android: because the content script's own click
can't be observed for completion the way a tracked API call can, "Download
concluded" there means *the save was successfully handed off to the page*,
not a guarantee that the OS finished writing the file to disk — for the
vast majority of downloads these happen effectively together, but if a
finished download still doesn't appear in your Downloads location, that's
the gap. Desktop downloads don't have this gap, since they're tracked all
the way through via `downloads.onChanged`.

Some mobile save dialogs (Android's system file picker in particular)
suggest a filename from the page's title rather than fully respecting the
name this extension requests. To work around that, the page's title is
set to the exact computed filename for the moment the save is triggered,
then restored right after — so the suggested name matches what you'd
expect (title, creator/uploader if included, resolution) rather than just
the bare video title. This workaround only applies to the Android save
path, since desktop doesn't go through a content script at all.

### Downloads survive the popup closing

The actual downloading runs in the extension's **background script**, not in
the popup. In Firefox, the popup's JS is destroyed the moment it loses focus
(switching tabs, clicking outside it, etc.) — that used to kill an in-progress
download with it. Now it doesn't:

- Click Download selected, then switch tabs or close the popup freely — every
  download you started keeps running in the background.
- Reopen the popup at any point and it immediately shows the same layout as
  always, with each of this tab's in-progress downloads appearing inline in
  place of that resolution's checkbox — size, speed, progress, and small
  working ⏸/✕ pause/cancel buttons next to the status line, right where
  you checked the box.
- Once a download finishes (success or failure), reopening the popup keeps
  showing that inline result until you click its small **×** button, which
  turns that row back into a normal checkbox so you can start it again.

This relies on Firefox's non-persistent "event page" background model, which
keeps the background script running for as long as it's actively doing work
(a periodic keep-alive alarm is used to help it stay awake through pauses,
too). In the rare case the browser reclaims the background page mid-download
anyway (most likely after a very long pause), the popup will show a clear
"Download was interrupted" error rather than silently getting stuck — just
start the download again if that happens.

### Multiple simultaneous downloads

Downloads are tracked per resolution per tab, so you can run several at
once in two different ways, together or separately:

- **Multiple resolutions of the same video**: check more than one box (or
  "All") before clicking Download selected, and each resolution downloads
  in parallel, each showing its own inline progress in place of its
  checkbox.
- **Different tabs**: start a download in one pmvhaven.com tab, switch to
  another, and start a download there too — neither affects the other.

Opening the popup always shows the resolution rows for whichever tab is
currently active, so each tab's popup only ever displays (and controls)
that tab's own downloads.

If a tab is closed while one of its downloads is still running, that
download keeps going in the background and still saves the finished file —
there's just no longer a popup to show its progress in, since the tab it
belongs to is gone.

### Cancel takes effect immediately

Each download's Cancel button interrupts things right away, even if it
lands mid-request or right as a file is being handed off to Firefox's
download manager:

- If a segment or playlist fetch is in flight, cancelling aborts that
  network request immediately instead of waiting for it to finish.
- If cancel is clicked right as the file is being handed to Firefox's
  downloads API (the "Assembling file…" step), the resulting download is
  cancelled and the partial file removed rather than being left behind.
- The moment you cancel a resolution's download, that row reverts to its
  checkbox immediately, so you can restart it right away if you want to —
  no need to dismiss anything first.

### Automatic retry on failure

Network hiccups mid-download no longer require manually clicking Download
again. If a segment fails to fetch, it's retried automatically in place —
up to 10 attempts total, waiting 2 seconds between each — before the
whole download is finally counted as failed. That's a single flat count:
there's no separate "restart the whole download from scratch" layer on top
of it, so you'll only ever see two kinds of status updates during a rough
patch:

- `Segment X of Y failed (attempt n/10)` while it's retrying, and
- `Download failed after 10 attempts` if it never recovers.

Cancelling at any point stops the retries immediately. If a download does
end up failing, its row shows a **↻ Retry** button next to the status
text — clicking it starts that exact download over again (same resolution
and filename) without needing to dismiss the error first or re-check
anything.

Whichever way a download ends, a small green ✓ (success) or red ✕ (failure)
appears right next to that resolution's name — first in the progress row,
and it stays there next to the checkbox even after you dismiss the card, so
you can see at a glance which resolutions you've already downloaded (or had
fail) without needing to remember. It updates again the next time you
download that resolution.

A small unlabeled **×** button — styled the same as each row's own dismiss
button — sits on the same line as the **All** checkbox and dismisses every
currently finished download for this tab at once, the same as clicking
each row's individual × dismiss button, just in one go. It has no effect
on downloads still in progress, and it's only shown at all when at least
one finished download's card is currently visible — it's hidden the rest
of the time.

If the popup can't find a video on the current page at all (wrong site, or
the page structure changed), the Resolution section shows a plain **–**
instead of the checkbox list — same as Title, Creator, and Uploader do when
nothing was found — rather than showing an empty, unusable "All"/dismiss-all
row.

## Firefox for Android

WebExtensions are cross-platform by design, so this is not a separate
build — the exact same `manifest.json` and files here run on Firefox for
Android too. `browser_specific_settings.gecko_android` in `manifest.json`
declares that compatibility, and `popup.html` has a viewport meta tag so
the popup scales correctly on a phone screen.

A few real differences to expect on Android, rather than desktop-parity
promises:

- **Sideloading is more limited.** The general-release Firefox for Android
  app only installs extensions listed on addons.mozilla.org. To test this
  unsigned build, use Firefox Nightly or Beta for Android (which allow a
  custom add-on collection) or connect the device to `about:debugging` on
  desktop Firefox over USB for remote debugging/installation.
- **Cancel may not remove the partial file.** `browser.downloads.cancel()`
  and `.removeFile()` are used to clean up when you cancel mid-download;
  if either isn't available on a given Android version, cancelling still
  stops the download immediately (the fetch itself is aborted), but a
  partial file may be left in your Downloads folder for you to delete
  manually.
- **The color/greyscale toolbar icon likely won't show.** Android's
  extension UI doesn't expose a persistent per-tab toolbar button the way
  desktop does, so `browser.action.setIcon()` with a `tabId` may simply
  have no visible effect there. This is purely cosmetic — the popup and
  downloading work the same either way.

## Load it in Firefox (temporary, for testing)

1. Go to `about:debugging#/runtime/this-firefox`
2. Click **Load Temporary Add-on…**
3. Select the `manifest.json` file in this folder.
4. Open a video page on pmvhaven.com, click the extension's toolbar icon.

This stays installed until you close Firefox. To make it permanent without
Mozilla's signing process, Firefox needs to be a Developer Edition/Nightly/
ESR build with `xpinstall.signatures.required` set to `false` in
`about:config` — otherwise just reload it as a temporary add-on each session.

## If you don't see the icon in the toolbar

Click the puzzle-piece icon (**»**) at the right end of the toolbar, find
"PMVHaven Downloader" in the list, and click its pin icon (or right-click →
"Pin to Toolbar").

## If something breaks

- **"Could not find the video stream info on this page"** — the site changed
  its JSON-LD structure. Open DevTools → Elements, search for
  `application/ld+json`, and check whether a block with `"@type":
  "VideoObject"` and a `contentUrl` ending in `.m3u8` still exists. If the
  field name changed, update the matching logic in `content.js`
  (`getVideoJsonLd`). Note: this warning is skipped on the bare
  pmvhaven.com homepage, since no video is expected there — you'll see a
  simple prompt to open a video page instead.
- **"No resolutions were found"** — the master playlist format changed.
  Fetch the master playlist URL directly in a browser tab and check it still
  has `#EXT-X-STREAM-INF` lines; adjust `parseMasterPlaylist` in `popup.js`
  if the tags differ.
- **A segment fails partway through** — this is now retried automatically
  (see "Automatic retry on failure" above). If you still see a failure
  message after all 10 attempts are exhausted, it's likely a longer-lived
  network or server issue; use the row's **↻ Retry** button or click
  Download again.
- **"Download was interrupted"** — see "Downloads survive the popup closing"
  above; this is rare and just means starting the download again.
- **The extension needs a new CDN domain** — if pmvhaven switches storage
  providers, the video segments will be served from a different domain than
  `pmvhavencloud.s3.eu-west-par.io.cloud.ovh.net`. Add the new domain to
  `host_permissions` in `manifest.json` and reload the extension.

## Notes

- The toolbar icon shows in color on pmvhaven.com tabs and on internal
  Firefox `about:` pages (like `about:addons` or `about:debugging`), and
  greyscale on every other tab, updating automatically as you switch tabs
  or navigate.
- The popup opens in **dark mode by default**. A moon/sun toggle in its
  top-right corner switches between dark and light mode — it's a plain
  monochrome icon (not colored emoji), so it always matches the current
  theme instead of the sun rendering yellow. Your choice is saved (via
  `browser.storage.local`) and applied automatically the next time you open
  the popup.
- Filenames are sanitized to strip characters that aren't allowed in file
  names (`\ / : * ? " < > |`).
- This only reassembles segments the page's own player already fetches
  during normal playback — it doesn't bypass any login, paywall, or DRM.

## Toolbar icon status

The toolbar icon of a tab reflects that tab's downloads: it gets a green
checkmark badge once every download started from the tab has finished
(and none failed), and a red x (same as in the download cards) as soon as any download fails. The
badge stays until the finished/failed cards are dismissed in the popup
(or the tab navigates), then the normal color/grey icon returns. Icons are
`icon<size>_done.png` and `icon<size>_error.png`.
